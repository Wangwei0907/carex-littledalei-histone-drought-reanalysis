# Carex littledalei histone and drought-response analyses

This repository contains selected analytical source code, public accession and
download manifests, a processed Carex PEG expression matrix, and derived
numerical result tables supporting the manuscript. It is a curated subset of
the submission's analysis archive, not a one-command reproduction bundle.

## Carex PEG data boundary

The 84-gene by 18-sample Carex FPKM matrix and its PEG sample metadata are
provided under `data/inputs/`, together with the sample-level PEG
PCA table and the aggregate PEG contrast, group-summary, robustness, influence,
and QC tables under `data/derived/`. These are the
project's processed inputs and derived results; they are not raw sequencing
files.

The source ZIP also contained a 1,512-row Figure 2B heatmap table, but its
`gene` field was blank for every row. It is intentionally omitted rather than
publishing a numerically present but semantically unmappable table; the
released matrix is the authoritative input for regenerating that panel.

The PEG analysis is inspectable from the released matrix and sample metadata,
but it is still not a one-command reproduction: the archived ZIP does not
contain the strict omnibus factor-test input expected by
`server_peg_robustness.R`, nor every external annotation and software
environment used in the original run. Do not infer missing inputs from result
tables; regenerate them from the released matrix or supply the corresponding
approved project input.

Raw FASTQ, BAM, genome indexes, and all reference FASTA files are absent.
The accession manifests identify public sources without redistributing those
files. In particular, the RBH script requires the NCBI Carex assembly protein
and GFF plus Arabidopsis/TAIR10 peptide references obtained from their official
sources. Check the applicable NCBI and Ensembl/TAIR10 terms before bundling
any reference sequence.

## Contents

- `CODE/` contains thirteen selected scripts covering the raw GSE226105
  driver, DESeq2, GO enrichment, PEG robustness, revised canonical-93
  leave-one-out analysis, final meta-analysis/QC, reciprocal-hit analysis,
  and Supplementary Figure S1 plotting. The raw GSE226105 driver was
  changed only at its executable-path constants: internal server paths are
  now environment variables (`CAREX_FASTP`, `CAREX_STAR`,
  `CAREX_FEATURECOUNTS`, `CAREX_SAMTOOLS`, and `CAREX_RSCRIPT`) with ordinary
  command-name defaults.
- `data/public_accession_manifests/` contains the selected ENA/SRA manifest,
  project run information, and the TAIR10 reference download manifest.
- `data/derived/` contains numerical tables from the public GSE/GEO analyses,
  cross-dataset summaries, RBH result tables, and PEG sample-level and
  aggregate summaries selected from the audited archive.
- `SHA256SUMS.tsv` records SHA-256 hashes for every other repository file using
  repository-relative paths; the manifest intentionally omits its own hash.

No images, logs, provenance ledgers, checksum files from the private server,
Slurm/build wrappers, document-assembly code, Python bytecode, or internal
absolute paths are included.

## External software and rerun limits

- Python scripts use Python 3 and, where applicable, pandas, NumPy, SciPy,
  and the DIAMOND executable.
- The DESeq2 script requires R with DESeq2 and optionally apeglm.
- The cold-response plotting script requires R packages data.table, ggplot2,
  and cowplot.
- The raw GSE driver additionally requires wget, fastp, STAR, featureCounts,
  samtools, an Rscript executable, the public FASTQ files, the reference
  index/GTF, and project metadata not bundled here.
- The deposited-matrix validator requires the separately obtained deposited
  normalized matrix and ortholog-evidence input. Those source-specific inputs
  are not included here.

The included tables are frozen derived outputs, not a replacement for raw-data
deposition. A clean-directory smoke test can validate Python parsing and
table schemas, but full DESeq2, PEG, RBH, and cold-response reruns require the
external inputs and software listed above.

## Availability and reuse boundary

The original analysis code is released under the MIT License in `LICENSE`.
The processed data are shared for inspection and reanalysis; this software
license does not assert rights over third-party source data.

The reference sequences, raw sequencing reads, and external software required
for some analyses must be obtained separately from their original providers.
The released scripts and processed tables support inspection of the reported
analyses, but the missing external inputs and software limit complete
end-to-end reruns. The original providers' terms apply to any separately
obtained third-party resources.
