#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(data.table))

input_root <- Sys.getenv(
  "CAREX_INPUT_ROOT",
  "."
)
source_root <- Sys.getenv(
  "CAREX_SOURCE_ROOT",
  "."
)
output_root <- Sys.getenv(
  "CAREX_OUTPUT_ROOT",
  "."
)
res_in <- file.path(input_root, "results")
res_out <- file.path(output_root, "results")
dir.create(res_out, recursive = TRUE, showWarnings = FALSE)

read_result <- function(name) {
  fread(file.path(res_in, name), na.strings = c("", "NA"))
}

meta <- read_result("Arabidopsis_56_two_dataset_effect_meta_analysis.tsv")
loo <- read_result("Arabidopsis_56_leave_one_sample_out_summary.tsv")
lab226 <- read_result("GSE226105_balanced_label_permutation_GSEA.tsv")
lab243 <- read_result("GSE243365_balanced_label_permutation_GSEA.tsv")
cons <- fread(file.path(
  source_root, "enrichment", "results",
  "GSE226105_GSE243365_GO_BP_GSEA_consensus.tsv"
))

## k = 2 Hartung-Knapp and strict cross-dataset replication audit ----------
hk_one <- function(y1, se1, y2, se2, tau2) {
  y <- c(y1, y2)
  se <- c(se1, se2)
  w <- 1 / (se^2 + tau2)
  mu <- sum(w * y) / sum(w)
  q_scale <- sum(w * (y - mu)^2)
  se_hk <- sqrt(q_scale / sum(w))
  se_mkh <- sqrt(max(1, q_scale) / sum(w))
  df <- 1
  data.table(
    hk_log2FC = mu,
    hk_SE = se_hk,
    hk_t = ifelse(se_hk > 0, mu / se_hk, NA_real_),
    hk_df = df,
    hk_CI95_low = mu - qt(0.975, df) * se_hk,
    hk_CI95_high = mu + qt(0.975, df) * se_hk,
    hk_pvalue = ifelse(se_hk > 0, 2 * pt(-abs(mu / se_hk), df), NA_real_),
    modified_hk_SE = se_mkh,
    modified_hk_CI95_low = mu - qt(0.975, df) * se_mkh,
    modified_hk_CI95_high = mu + qt(0.975, df) * se_mkh,
    modified_hk_pvalue = 2 * pt(-abs(mu / se_mkh), df),
    hk_variance_scale = q_scale
  )
}

complete <- meta[meta_estimable_two_datasets == TRUE]
hk <- rbindlist(lapply(seq_len(nrow(complete)), function(i) {
  z <- complete[i]
  cbind(
    z[, .(AGI)],
    hk_one(
      z$log2FC_GSE226105, z$SE_GSE226105,
      z$log2FC_GSE243365, z$SE_GSE243365,
      z$tau2_DL
    )
  )
}))
hk[, hk_FDR_48 := p.adjust(hk_pvalue, method = "BH")]
hk[, modified_hk_FDR_48 := p.adjust(modified_hk_pvalue, method = "BH")]

loo226 <- loo[dataset == "GSE226105", .(
  AGI,
  loo_direction_stability_GSE226105 = direction_stability_fraction,
  loo_FDR_retention_GSE226105 = FDR005_retained_fraction
)]
loo243 <- loo[dataset == "GSE243365", .(
  AGI,
  loo_direction_stability_GSE243365 = direction_stability_fraction,
  loo_FDR_retention_GSE243365 = FDR005_retained_fraction
)]

final_meta <- merge(meta, hk, by = "AGI", all.x = TRUE)
final_meta <- merge(final_meta, loo226, by = "AGI", all.x = TRUE)
final_meta <- merge(final_meta, loo243, by = "AGI", all.x = TRUE)
final_meta[, both_datasets_FDR005 :=
             !is.na(FDR_GSE226105) & !is.na(FDR_GSE243365) &
             FDR_GSE226105 < 0.05 & FDR_GSE243365 < 0.05]
final_meta[, fixed_random_direction_agree :=
             meta_estimable_two_datasets &
             sign(fixed_log2FC) == sign(random_log2FC)]
final_meta[, loo_direction_stable_both :=
             !is.na(loo_direction_stability_GSE226105) &
             !is.na(loo_direction_stability_GSE243365) &
             loo_direction_stability_GSE226105 == 1 &
             loo_direction_stability_GSE243365 == 1]
final_meta[, strict_replication :=
             meta_estimable_two_datasets & same_direction_raw &
             both_datasets_FDR005 & fixed_random_direction_agree &
             loo_direction_stable_both]
final_meta[, strict_replication_definition := paste(
  "same raw direction; both individual FDR < 0.05;",
  "fixed/random signs agree; leave-one-sample-out direction stability = 1 in both datasets"
)]

fwrite(
  final_meta,
  file.path(res_out, "Candidate_meta_HKSJ_and_strict_replication.tsv"),
  sep = "\t"
)
fwrite(
  final_meta[strict_replication == TRUE],
  file.path(res_out, "Strictly_replicated_candidate_groups.tsv"),
  sep = "\t"
)

## Canonical exact-pipeline 93-term set and legacy transition audit --------
obs226 <- lab226[is_observed_allocation == TRUE]
obs243 <- lab243[is_observed_allocation == TRUE]
obs <- merge(
  obs226[, .(GO_ID, exact_NES_226 = NES, exact_padj_226 = padj)],
  obs243[, .(GO_ID, exact_NES_243 = NES, exact_padj_243 = padj)],
  by = "GO_ID"
)
obs[, exact_same_direction := sign(exact_NES_226) == sign(exact_NES_243)]
obs[, exact_canonical_FDR005 :=
      exact_padj_226 < 0.05 & exact_padj_243 < 0.05 & exact_same_direction]
legacy <- cons[consensus_FDR_005 == TRUE & same_direction == TRUE]
legacy_ids <- legacy$GO_ID
exact_ids <- obs[exact_canonical_FDR005 == TRUE, GO_ID]

go_terms <- unique(cons[, .(GO_ID, GO_term)])
transition <- merge(
  merge(
    go_terms,
    cons[, .(
      GO_ID,
      legacy_NES_226 = NES_GSE226105,
      legacy_padj_226 = padj_GSE226105,
      legacy_NES_243 = NES_GSE243365,
      legacy_padj_243 = padj_GSE243365
    )],
    by = "GO_ID", all.x = TRUE
  ),
  obs,
  by = "GO_ID", all = TRUE
)
transition[, legacy_primary94 := GO_ID %in% legacy_ids]
transition[, exact_canonical93 := GO_ID %in% exact_ids]
transition[, transition_status := fifelse(
  legacy_primary94 & exact_canonical93, "retained",
  fifelse(legacy_primary94 & !exact_canonical93, "lost_from_legacy94",
          fifelse(!legacy_primary94 & exact_canonical93, "gained_in_exact93", "neither"))
)]
transition_audit <- transition[transition_status != "neither"]
setorder(transition_audit, transition_status, GO_ID)
fwrite(
  transition_audit,
  file.path(res_out, "GO_exact93_transition_audit.tsv"),
  sep = "\t"
)
fwrite(
  transition[exact_canonical93 == TRUE],
  file.path(res_out, "GO_exact93_canonical_set.tsv"),
  sep = "\t"
)

## Dataset role and eligibility table --------------------------------------
dataset_audit <- data.table(
  evidence_source = c("GSE226105", "GSE243365", "Published ATH1 meta-analysis"),
  role = c(
    "Independent count-level benchmarking case study",
    "Independent count-level benchmarking case study",
    "Contextual published evidence only"
  ),
  included_in_two_dataset_meta = c(TRUE, TRUE, FALSE),
  prespecified_eligibility = c(
    "Arabidopsis; drought-versus-control; biological replication; count-level data; estimable candidate homolog effects",
    "Arabidopsis; drought-versus-control; biological replication; official count-level data; estimable candidate homolog effects",
    "Published candidate-level context; not combined with RNA-seq effects"
  ),
  included_samples = c(
    "3 control and 3 drought samples",
    "3 wild-type leaf input-RNA control and 3 wild-type leaf input-RNA drought samples",
    "Not applicable"
  ),
  excluded_material = c(
    "None within the prespecified six-sample contrast",
    "Mutant, immunoprecipitation, polysome and GMUCT libraries were excluded from the prespecified input-RNA contrast",
    "Excluded from quantitative pooling"
  ),
  selection_scope = c(
    "Benchmarking case study; not a systematic-review search",
    "Benchmarking case study; not a systematic-review search",
    "Context only"
  )
)
fwrite(dataset_audit, file.path(res_out, "Dataset_eligibility_and_role.tsv"), sep = "\t")

facts <- data.table(
  metric = c(
    "candidate_two_dataset_estimable_groups",
    "strictly_replicated_candidate_groups",
    "HK_FDR005_groups",
    "modified_HK_FDR005_groups",
    "legacy_primary_GO_terms",
    "exact_canonical_GO_terms",
    "GO_terms_lost_from_legacy94",
    "GO_terms_gained_in_exact93"
  ),
  value = c(
    sum(final_meta$meta_estimable_two_datasets),
    sum(final_meta$strict_replication, na.rm = TRUE),
    sum(final_meta$hk_FDR_48 < 0.05, na.rm = TRUE),
    sum(final_meta$modified_hk_FDR_48 < 0.05, na.rm = TRUE),
    length(legacy_ids), length(exact_ids),
    sum(transition$transition_status == "lost_from_legacy94"),
    sum(transition$transition_status == "gained_in_exact93")
  )
)
fwrite(facts, file.path(res_out, "FINAL_REVIEW_ANALYSIS_FACTS.tsv"), sep = "\t")

stopifnot(
  nrow(final_meta) == 56L,
  sum(final_meta$meta_estimable_two_datasets) == 48L,
  length(legacy_ids) == 94L,
  length(exact_ids) == 93L,
  sum(transition$transition_status == "lost_from_legacy94") == 3L,
  sum(transition$transition_status == "gained_in_exact93") == 2L
)

writeLines(capture.output(sessionInfo()), file.path(res_out, "FINAL_REVIEW_sessionInfo.txt"))
writeLines(c(
  "PASS Hartung-Knapp and modified Hartung-Knapp sensitivities calculated for all 48 two-dataset groups",
  "PASS strict replication applies dataset-level FDR, direction, model-agreement and leave-one-sample-out criteria",
  "PASS exact-pipeline 93-term GO set is canonical and transition from the legacy 94-term set is explicit",
  "PASS dataset sources are framed as benchmarking case studies rather than a systematic review"
), file.path(res_out, "FINAL_REVIEW_ACCEPTANCE.txt"))

files <- list.files(res_out, full.names = TRUE)
hashes <- tools::md5sum(files)
manifest <- data.table(file = basename(names(hashes)), md5 = unname(hashes))
fwrite(manifest, file.path(output_root, "FINAL_REVIEW_MD5SUMS.tsv"), sep = "\t")

print(facts)
print(final_meta[strict_replication == TRUE, .(AGI, carex_genes, arabidopsis_symbols)])
print(transition[transition_status %chin% c("lost_from_legacy94", "gained_in_exact93"),
                 .(GO_ID, GO_term, transition_status, exact_padj_226, exact_padj_243)])
