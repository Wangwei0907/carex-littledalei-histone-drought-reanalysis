#!/usr/bin/env python3
import csv, hashlib, json, os, pathlib, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT=pathlib.Path(__file__).resolve().parents[1]
ENA=ROOT/'metadata/ena/PRJNA938512_runinfo.tsv'
SAMPLES=ROOT/'metadata/GSE226105_PRESPECIFIED_SAMPLES.tsv'
OUT=ROOT/'raw_fastq'
LOG=ROOT/'logs/download'
MANIFEST=ROOT/'metadata/ena/GSE226105_selected_fastq_manifest.tsv'
MARKER=ROOT/'metadata/ena/GSE226105_FASTQ_MD5_OK.txt'
OUT.mkdir(parents=True, exist_ok=True); LOG.mkdir(parents=True, exist_ok=True)

def md5sum(path, block=8*1024*1024):
    h=hashlib.md5()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(block),b''): h.update(chunk)
    return h.hexdigest()

with open(SAMPLES, newline='', encoding='utf-8') as f:
    samples=list(csv.DictReader(f, delimiter='\t'))
assert len(samples)==6 and {x['condition'] for x in samples}=={'control','drought'}
by_gsm={x['gsm']:x for x in samples}
with open(ENA, newline='', encoding='utf-8') as f:
    ena=list(csv.DictReader(f, delimiter='\t'))
selected=[x for x in ena if x['sample_alias'] in by_gsm]
assert len(selected)==6, f'Expected 6 ENA rows, got {len(selected)}'
rows=[]
for e in selected:
    s=by_gsm[e['sample_alias']]
    assert e['library_layout']=='PAIRED'
    assert e['experiment_accession']==s['srx'] and e['sample_accession']==s['biosample']
    urls=e['fastq_ftp'].split(';'); md5s=e['fastq_md5'].split(';'); sizes=e['fastq_bytes'].split(';')
    assert len(urls)==len(md5s)==len(sizes)==2
    for mate,(url,md5,size) in enumerate(zip(urls,md5s,sizes),1):
        filename=f"{e['run_accession']}_{mate}.fastq.gz"
        rows.append(dict(sample_id=s['sample_id'],gsm=s['gsm'],condition=s['condition'],replicate=s['replicate'],run_accession=e['run_accession'],experiment_accession=e['experiment_accession'],sample_accession=e['sample_accession'],mate=str(mate),url='https://'+url,md5=md5,bytes=size,filename=filename))
rows.sort(key=lambda x:(x['sample_id'],x['mate']))
fields=list(rows[0])
with open(MANIFEST,'w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n'); w.writeheader(); w.writerows(rows)

def download(row):
    dest=OUT/row['filename']; part=pathlib.Path(str(dest)+'.part'); log=LOG/(row['filename']+'.log')
    if dest.exists() and dest.stat().st_size==int(row['bytes']) and md5sum(dest)==row['md5']:
        return {'filename':row['filename'],'status':'already_valid','bytes':dest.stat().st_size,'md5':row['md5']}
    if dest.exists(): dest.unlink()
    for attempt in range(1,6):
        with open(log,'a',encoding='utf-8') as lf:
            lf.write(f'ATTEMPT {attempt} {time.strftime("%FT%TZ",time.gmtime())}\n')
            p=subprocess.run(['wget','--continue','--tries=5','--timeout=60','--output-document',str(part),row['url']],stdout=lf,stderr=subprocess.STDOUT)
        if p.returncode==0 and part.exists():
            got=md5sum(part)
            if got==row['md5'] and part.stat().st_size==int(row['bytes']):
                os.replace(part,dest)
                return {'filename':row['filename'],'status':'downloaded_valid','bytes':dest.stat().st_size,'md5':got}
            with open(log,'a',encoding='utf-8') as lf: lf.write(f'MISMATCH size={part.stat().st_size} md5={got}\n')
            part.unlink(missing_ok=True)
        time.sleep(min(30,5*attempt))
    raise RuntimeError(f"Download/MD5 failed: {row['filename']}")

results=[]
with ThreadPoolExecutor(max_workers=3) as ex:
    futs={ex.submit(download,r):r for r in rows}
    for fut in as_completed(futs):
        ans=fut.result(); results.append(ans); print(json.dumps(ans),flush=True)
assert len(results)==12
for row in rows:
    p=OUT/row['filename']; assert p.exists() and p.stat().st_size==int(row['bytes']) and md5sum(p)==row['md5']
with open(MARKER,'w',encoding='utf-8') as f:
    f.write('GSE226105_SELECTED_FASTQ_MD5_OK\n')
    f.write(f'files\t{len(rows)}\nbytes\t{sum(int(x["bytes"]) for x in rows)}\n')
    f.write(time.strftime('verified_utc\t%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
print('ALL_FASTQ_MD5_OK',len(rows),sum(int(x['bytes']) for x in rows),flush=True)
