#!/usr/bin/env python3
import csv, hashlib, json, os, pathlib, re, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
FASTP=pathlib.Path(os.environ.get('CAREX_FASTP', 'fastp'))
STAR=pathlib.Path(os.environ.get('CAREX_STAR', 'STAR'))
FC=pathlib.Path(os.environ.get('CAREX_FEATURECOUNTS', 'featureCounts'))
SAMTOOLS=pathlib.Path(os.environ.get('CAREX_SAMTOOLS', 'samtools'))
RSCRIPT=pathlib.Path(os.environ.get('CAREX_RSCRIPT', 'Rscript'))
META=ROOT/'metadata/GSE226105_PRESPECIFIED_SAMPLES.tsv'
FMAN=ROOT/'metadata/ena/GSE226105_selected_fastq_manifest.tsv'
REF=ROOT/'reference/tair10_ensembl_plants_63'
INDEX=REF/'star_index'; GTF=REF/'Arabidopsis_thaliana.TAIR10.63.gtf'
ORTH=ROOT/'inputs/arabidopsis_ortholog_true_drought_evidence.tsv'
RAW=ROOT/'raw_fastq'; TRIM=ROOT/'trimmed_fastq'; ALIGN=ROOT/'align'; QC=ROOT/'qc'; LOG=ROOT/'logs'; RESULTS=ROOT/'results/gse226105_raw_reanalysis'
for d in [TRIM,ALIGN,QC/'fastp',QC/'star',QC/'featurecounts',LOG/'fastp',LOG/'star',RESULTS]: d.mkdir(parents=True,exist_ok=True)

def run(cmd, log):
    log=pathlib.Path(log); log.parent.mkdir(parents=True,exist_ok=True)
    with open(log,'w',encoding='utf-8') as f:
        f.write('COMMAND\t'+json.dumps([str(x) for x in cmd])+'\n'); f.flush()
        subprocess.run([str(x) for x in cmd],stdout=f,stderr=subprocess.STDOUT,check=True)

def sha256(path, block=8*1024*1024):
    z=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(block),b''): z.update(b)
    return z.hexdigest()

assert (ROOT/'metadata/ena/GSE226105_FASTQ_MD5_OK.txt').exists(), 'FASTQ MD5 marker absent'
with open(META,newline='',encoding='utf-8') as f: samples=list(csv.DictReader(f,delimiter='\t'))
with open(FMAN,newline='',encoding='utf-8') as f: manifest=list(csv.DictReader(f,delimiter='\t'))
assert len(samples)==6 and len(manifest)==12
by_sample={s['sample_id']:s for s in samples}
for s in samples:
    rows=[r for r in manifest if r['sample_id']==s['sample_id']]
    assert len(rows)==2 and {r['mate'] for r in rows}=={'1','2'}
    run_id=rows[0]['run_accession']; r1=RAW/f'{run_id}_1.fastq.gz'; r2=RAW/f'{run_id}_2.fastq.gz'
    o1=TRIM/f"{s['sample_id']}_R1.fastq.gz"; o2=TRIM/f"{s['sample_id']}_R2.fastq.gz"
    js=QC/'fastp'/f"{s['sample_id']}.json"; html=QC/'fastp'/f"{s['sample_id']}.html"
    if not (o1.exists() and o2.exists() and js.exists()):
        run([FASTP,'-i',r1,'-I',r2,'-o',o1,'-O',o2,'--thread','4','--detect_adapter_for_pe','--length_required','30','--json',js,'--html',html,'--report_title',s['sample_id']],LOG/'fastp'/f"{s['sample_id']}.log")
    ad=ALIGN/s['gsm']; ad.mkdir(parents=True,exist_ok=True); prefix=str(ad/(s['gsm']+'.'))
    bam=ad/(s['gsm']+'.Aligned.sortedByCoord.out.bam')
    if not (bam.exists() and (ad/(s['gsm']+'.Log.final.out')).exists()):
        run([STAR,'--runThreadN','8','--genomeDir',INDEX,'--readFilesIn',o1,o2,'--readFilesCommand','zcat','--twopassMode','Basic','--outFileNamePrefix',prefix,'--outSAMtype','BAM','SortedByCoordinate','--outSAMattributes','NH','HI','AS','nM','--quantMode','GeneCounts','--limitBAMsortRAM','12000000000'],LOG/'star'/f"{s['sample_id']}.log")
    if not pathlib.Path(str(bam)+'.bai').exists(): run([SAMTOOLS,'index','-@','4',bam],LOG/'star'/f"{s['sample_id']}.samtools_index.log")

bams=[ALIGN/s['gsm']/(s['gsm']+'.Aligned.sortedByCoord.out.bam') for s in samples]
fc_out=RESULTS/'GSE226105_featureCounts_gene_counts.txt'
run([FC,'-T','8','-p','--countReadPairs','-B','-C','-F','GTF','-t','exon','-g','gene_id','-a',GTF,'-o',fc_out,*bams],LOG/'featurecounts.log')
# Convert featureCounts output to a strict gene-by-GSM integer matrix.
with open(fc_out,newline='',encoding='utf-8') as f:
    data=[line for line in f if not line.startswith('#')]
reader=csv.DictReader(data,delimiter='\t'); fc_rows=list(reader); fc_cols=reader.fieldnames
assert fc_cols and fc_cols[:6]==['Geneid','Chr','Start','End','Strand','Length'] and len(fc_cols)==12
bam_cols=fc_cols[6:]
col_for_gsm={gsm:next((x for x in bam_cols if gsm in x),None) for gsm in [s['gsm'] for s in samples]}
assert all(col_for_gsm.values()) and len(set(col_for_gsm.values()))==6
counts=RESULTS/'GSE226105_raw_gene_counts.tsv'
with open(counts,'w',newline='',encoding='utf-8') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n'); w.writerow(['Geneid']+[s['gsm'] for s in samples])
    for row in fc_rows:
        vals=[row[col_for_gsm[s['gsm']]] for s in samples]
        assert all(v.isdigit() for v in vals)
        w.writerow([row['Geneid'],*vals])
# Summarize fastp, STAR, and featureCounts QC.
fc_summary={}
with open(str(fc_out)+'.summary',newline='',encoding='utf-8') as f:
    rr=csv.DictReader(f,delimiter='\t')
    for row in rr:
        status=row['Status']
        for s in samples: fc_summary.setdefault(s['gsm'],{})[status]=int(row[col_for_gsm[s['gsm']]])
qc_rows=[]
for s in samples:
    with open(QC/'fastp'/f"{s['sample_id']}.json",encoding='utf-8') as f: fj=json.load(f)
    before=fj['summary']['before_filtering']; after=fj['summary']['after_filtering']
    star={}
    with open(ALIGN/s['gsm']/(s['gsm']+'.Log.final.out'),encoding='utf-8') as f:
        for line in f:
            if '|' in line:
                k,v=line.split('|',1); star[k.strip()]=v.strip()
    fc=fc_summary[s['gsm']]; fc_total=sum(fc.values()); assigned=fc.get('Assigned',0)
    qc_rows.append(dict(sample_id=s['sample_id'],gsm=s['gsm'],condition=s['condition'],raw_read_pairs=int(before['total_reads'])//2,fastp_pass_rate=after['total_reads']/before['total_reads'],fastp_q30_rate=after['q30_rate'],star_uniquely_mapped_rate=float(star['Uniquely mapped reads %'].rstrip('%'))/100,star_mapped_to_multiple_loci_rate=float(star['% of reads mapped to multiple loci'].rstrip('%'))/100,featurecounts_assigned_fragments=assigned,featurecounts_total_fragments=fc_total,featurecounts_assigned_rate=assigned/fc_total))
qcf=QC/'GSE226105_sample_QC.tsv'
with open(qcf,'w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(qc_rows[0]),delimiter='\t',lineterminator='\n'); w.writeheader(); w.writerows(qc_rows)
# Prespecified technical acceptance thresholds; no sample exclusion is performed.
checks=[]
for q in qc_rows:
    checks += [(q['sample_id'],'raw_read_pairs_ge_5M',q['raw_read_pairs']>=5_000_000,q['raw_read_pairs']), (q['sample_id'],'fastp_pass_rate_ge_0.80',q['fastp_pass_rate']>=0.80,q['fastp_pass_rate']), (q['sample_id'],'fastp_q30_rate_ge_0.80',q['fastp_q30_rate']>=0.80,q['fastp_q30_rate']), (q['sample_id'],'star_unique_rate_ge_0.60',q['star_uniquely_mapped_rate']>=0.60,q['star_uniquely_mapped_rate']), (q['sample_id'],'featurecounts_assigned_rate_ge_0.40',q['featurecounts_assigned_rate']>=0.40,q['featurecounts_assigned_rate'])]
with open(QC/'GSE226105_QC_ACCEPTANCE.tsv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n'); w.writerow(['sample_id','criterion','pass','observed']); w.writerows(checks)
if not all(x[2] for x in checks): raise RuntimeError('One or more prespecified technical QC thresholds failed; inspect acceptance table')
# Formal DESeq2 model from raw integer counts.
de_out=RESULTS/'deseq2'; de_out.mkdir(parents=True,exist_ok=True)
run([RSCRIPT,ROOT/'scripts/server_gse226105_deseq2.R',counts,META,ORTH,de_out,'gsm','10','3'],LOG/'gse226105_deseq2.log')
# Final structural assertions and checksums.
with open(de_out/'GSE226105_prespecified_56_ortholog_DESeq2.tsv',newline='',encoding='utf-8') as f: orthres=list(csv.DictReader(f,delimiter='\t'))
assert len(orthres)==56 and len({x['AGI'] for x in orthres})==56
with open(de_out/'GSE226105_sample_PCA.tsv',newline='',encoding='utf-8') as f: pca=list(csv.DictReader(f,delimiter='\t'))
assert len(pca)==6
files=[p for p in ROOT.rglob('*') if p.is_file() and ('raw_fastq' not in p.parts) and ('trimmed_fastq' not in p.parts) and ('align' not in p.parts) and p.name not in {'PIPELINE_ACCEPTED.txt','analysis_outputs.sha256'}]
with open(RESULTS/'analysis_outputs.sha256','w',encoding='utf-8') as f:
    for p in sorted(files): f.write(f'{sha256(p)}  {p.relative_to(ROOT)}\n')
with open(RESULTS/'PIPELINE_ACCEPTED.txt','w',encoding='utf-8') as f:
    f.write('GSE226105_RAW_REANALYSIS_ACCEPTED\n')
    f.write('samples\t6\northolog_units\t56\n')
    f.write(time.strftime('completed_utc\t%Y-%m-%dT%H:%M:%SZ\n',time.gmtime()))
print('GSE226105_RAW_REANALYSIS_ACCEPTED',flush=True)
