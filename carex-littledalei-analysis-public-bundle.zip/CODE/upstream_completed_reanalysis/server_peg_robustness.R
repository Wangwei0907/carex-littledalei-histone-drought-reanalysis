#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3L) {
  stop("Usage: Rscript server_peg_robustness.R strict_84_fpkm_matrix.tsv strict_84_omnibus_factor_tests.tsv output_dir [permutations=10000] [seed=20260728]")
}

matrix_path <- normalizePath(args[[1]], mustWork = TRUE)
reference_path <- normalizePath(args[[2]], mustWork = TRUE)
output_dir <- args[[3]]
permutations <- if (length(args) >= 4L) as.integer(args[[4]]) else 10000L
seed <- if (length(args) >= 5L) as.integer(args[[5]]) else 20260728L
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read.delim(matrix_path, check.names = FALSE, stringsAsFactors = FALSE)
sample_names <- grep("^[KS][015]_[123]$", names(raw), value = TRUE)
if (length(sample_names) != 18L) stop("Expected 18 sample columns, found ", length(sample_names))
if (nrow(raw) != 84L) stop("Expected 84 strict genes, found ", nrow(raw))
if (anyDuplicated(raw$gene)) stop("Duplicate gene symbols in strict matrix")

accession <- factor(sub("^([KS]).*$", "\\1", sample_names), levels = c("K", "S"))
time_code <- sub("^[KS]([015])_.*$", "\\1", sample_names)
time <- factor(time_code, levels = c("0", "1", "5"), labels = c("0", "12", "72"))
replicate <- as.integer(sub("^.*_", "", sample_names))
group <- interaction(accession, time, sep = "_", drop = TRUE)
metadata <- data.frame(sample = sample_names, accession = accession, time_h = time, replicate = replicate, group = group)
write.table(metadata, file.path(output_dir, "peg_sample_metadata.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

Y <- t(log2(as.matrix(raw[, sample_names, drop = FALSE]) + 1))
colnames(Y) <- raw$gene
rownames(Y) <- sample_names

make_designs <- function(meta) {
  list(
    full = model.matrix(~ 0 + group, data = meta),
    additive = model.matrix(~ accession + time_h, data = meta),
    time_only = model.matrix(~ time_h, data = meta),
    accession_only = model.matrix(~ accession, data = meta)
  )
}

hat_matrix <- function(X) {
  q <- qr(X)
  Q <- qr.Q(q)
  Q %*% t(Q)
}

effect_definitions <- list(
  accession_joint = c("time_only", "full"),
  time_joint = c("accession_only", "full"),
  accession_time_interaction = c("additive", "full")
)

fit_effects <- function(y, meta) {
  designs <- make_designs(meta)
  out <- list()
  for (effect in names(effect_definitions)) {
    pair <- effect_definitions[[effect]]
    Xr <- designs[[pair[[1]]]]
    Xf <- designs[[pair[[2]]]]
    Hr <- hat_matrix(Xr)
    Hf <- hat_matrix(Xf)
    sse_r <- colSums(((diag(nrow(y)) - Hr) %*% y)^2)
    sse_f <- colSums(((diag(nrow(y)) - Hf) %*% y)^2)
    df1 <- qr(Xf)$rank - qr(Xr)$rank
    df2 <- nrow(y) - qr(Xf)$rank
    f_value <- pmax(0, ((sse_r - sse_f) / df1) / (sse_f / df2))
    estimable <- is.finite(f_value)
    f_value[!estimable] <- 0
    p_value <- pf(f_value, df1 = df1, df2 = df2, lower.tail = FALSE)
    p_value[!estimable] <- 1
    out[[effect]] <- data.frame(
      gene = colnames(y), effect = effect, F = f_value, p = p_value,
      FDR = p.adjust(p_value, method = "BH"), df1 = df1, df2 = df2,
      estimable = estimable, stringsAsFactors = FALSE
    )
  }
  do.call(rbind, out)
}

parametric <- fit_effects(Y, metadata)
rownames(parametric) <- NULL
reference <- read.delim(reference_path, check.names = FALSE, stringsAsFactors = FALSE)
for (effect in names(effect_definitions)) {
  f_col <- paste0(effect, "_F")
  p_col <- paste0(effect, "_p")
  fdr_col <- paste0(effect, "_FDR_strict84")
  idx <- parametric$effect == effect
  match_idx <- match(parametric$gene[idx], reference$gene)
  parametric$reference_F[idx] <- reference[[f_col]][match_idx]
  parametric$reference_p[idx] <- reference[[p_col]][match_idx]
  parametric$reference_FDR[idx] <- reference[[fdr_col]][match_idx]
}
parametric$absolute_F_difference <- abs(parametric$F - parametric$reference_F)
parametric$absolute_p_difference <- abs(parametric$p - parametric$reference_p)
parametric$absolute_FDR_difference <- abs(parametric$FDR - parametric$reference_FDR)
write.table(parametric, file.path(output_dir, "peg_parametric_reproduction.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

loo_list <- vector("list", length(sample_names))
for (i in seq_along(sample_names)) {
  keep <- seq_along(sample_names) != i
  one <- fit_effects(Y[keep, , drop = FALSE], droplevels(metadata[keep, , drop = FALSE]))
  one$omitted_sample <- sample_names[[i]]
  loo_list[[i]] <- one
}
leave_one_out <- do.call(rbind, loo_list)
rownames(leave_one_out) <- NULL
write.table(leave_one_out, file.path(output_dir, "peg_leave_one_sample_results.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

set.seed(seed)
permutation_list <- list()
designs <- make_designs(metadata)
I <- diag(nrow(Y))
for (effect in names(effect_definitions)) {
  pair <- effect_definitions[[effect]]
  Xr <- designs[[pair[[1]]]]
  Xf <- designs[[pair[[2]]]]
  Hr <- hat_matrix(Xr)
  Hf <- hat_matrix(Xf)
  Rr <- I - Hr
  Rf <- I - Hf
  fitted_reduced <- Hr %*% Y
  residual_reduced <- Rr %*% Y
  sse_r_obs <- colSums((Rr %*% Y)^2)
  sse_f_obs <- colSums((Rf %*% Y)^2)
  df1 <- qr(Xf)$rank - qr(Xr)$rank
  df2 <- nrow(Y) - qr(Xf)$rank
  f_obs <- pmax(0, ((sse_r_obs - sse_f_obs) / df1) / (sse_f_obs / df2))
  estimable_obs <- is.finite(f_obs)
  f_obs[!estimable_obs] <- 0
  exceed <- integer(ncol(Y))
  for (b in seq_len(permutations)) {
    permuted_y <- fitted_reduced + residual_reduced[sample.int(nrow(Y)), , drop = FALSE]
    sse_r <- colSums((Rr %*% permuted_y)^2)
    sse_f <- colSums((Rf %*% permuted_y)^2)
    f_perm <- pmax(0, ((sse_r - sse_f) / df1) / (sse_f / df2))
    f_perm[!is.finite(f_perm)] <- 0
    exceed <- exceed + as.integer(f_perm >= (f_obs - 1e-12))
  }
  empirical_p <- (exceed + 1) / (permutations + 1)
  permutation_list[[effect]] <- data.frame(
    gene = colnames(Y), effect = effect, observed_F = f_obs, estimable = estimable_obs,
    empirical_p = empirical_p, empirical_FDR = p.adjust(empirical_p, method = "BH"),
    permutations = permutations, seed = seed, stringsAsFactors = FALSE
  )
}
permutation_results <- do.call(rbind, permutation_list)
rownames(permutation_results) <- NULL
write.table(permutation_results, file.path(output_dir, "peg_freedman_lane_permutation_tests.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

influence_list <- lapply(seq_len(ncol(Y)), function(j) {
  fit <- lm(Y[, j] ~ 0 + group, data = metadata)
  cd <- suppressWarnings(cooks.distance(fit))
  finite_idx <- which(is.finite(cd))
  if (length(finite_idx) == 0L) {
    data.frame(
      gene = colnames(Y)[[j]], max_cooks_distance = NA_real_,
      most_influential_sample = NA_character_, threshold_4_over_n = 4 / nrow(Y),
      exceeds_4_over_n = FALSE, diagnostic_status = "not_estimable",
      stringsAsFactors = FALSE
    )
  } else {
    k <- finite_idx[[which.max(cd[finite_idx])]]
    data.frame(
      gene = colnames(Y)[[j]], max_cooks_distance = unname(cd[[k]]),
      most_influential_sample = sample_names[[k]], threshold_4_over_n = 4 / nrow(Y),
      exceeds_4_over_n = unname(cd[[k]]) > 4 / nrow(Y), diagnostic_status = "estimated",
      stringsAsFactors = FALSE
    )
  }
})
influence <- do.call(rbind, influence_list)
write.table(influence, file.path(output_dir, "peg_influence_diagnostics.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

summary_rows <- list()
counter <- 1L
for (effect in names(effect_definitions)) {
  full_block <- parametric[parametric$effect == effect, ]
  perm_block <- permutation_results[permutation_results$effect == effect, ]
  for (gene in colnames(Y)) {
    loo_block <- leave_one_out[leave_one_out$effect == effect & leave_one_out$gene == gene, ]
    full_row <- full_block[full_block$gene == gene, ]
    perm_row <- perm_block[perm_block$gene == gene, ]
    summary_rows[[counter]] <- data.frame(
      gene = gene, effect = effect, full_FDR = full_row$FDR,
      leave_one_out_significant_n = sum(loo_block$FDR < 0.05),
      leave_one_out_total = nrow(loo_block),
      leave_one_out_significant_fraction = mean(loo_block$FDR < 0.05),
      leave_one_out_min_FDR = min(loo_block$FDR), leave_one_out_max_FDR = max(loo_block$FDR),
      permutation_p = perm_row$empirical_p, permutation_FDR = perm_row$empirical_FDR,
      stable_confirmatory = isTRUE(full_row$FDR < 0.05) && isTRUE(mean(loo_block$FDR < 0.05) >= 0.80) && isTRUE(perm_row$empirical_FDR < 0.05),
      stringsAsFactors = FALSE
    )
    counter <- counter + 1L
  }
}
robustness <- do.call(rbind, summary_rows)
write.table(robustness, file.path(output_dir, "peg_robustness_summary.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

qc <- data.frame(
  metric = c(
    "genes", "samples", "permutations", "seed", "max_parametric_F_difference",
    "max_parametric_p_difference", "max_parametric_FDR_difference",
    "stable_accession_joint", "stable_time_joint", "stable_interaction",
    "genes_with_max_Cook_above_4_over_n"
  ),
  value = c(
    ncol(Y), nrow(Y), permutations, seed,
    max(parametric$absolute_F_difference, na.rm = TRUE),
    max(parametric$absolute_p_difference, na.rm = TRUE),
    max(parametric$absolute_FDR_difference, na.rm = TRUE),
    sum(robustness$effect == "accession_joint" & robustness$stable_confirmatory),
    sum(robustness$effect == "time_joint" & robustness$stable_confirmatory),
    sum(robustness$effect == "accession_time_interaction" & robustness$stable_confirmatory),
    sum(influence$exceeds_4_over_n)
  ),
  stringsAsFactors = FALSE
)
write.table(qc, file.path(output_dir, "peg_robustness_QC.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "R_sessionInfo.txt"))
writeLines(capture.output(print(qc, row.names = FALSE)), file.path(output_dir, "run_stdout.txt"))

