#!/usr/bin/env python3
import json, pathlib, sys
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr
ROOT=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
out=ROOT/'results/gse226105_raw_reanalysis/deposited_matrix_concordance'; out.mkdir(parents=True,exist_ok=True)
meta=pd.read_csv(ROOT/'metadata/GSE226105_PRESPECIFIED_SAMPLES.tsv',sep='\t',dtype=str)
dep=pd.read_csv(ROOT/'inputs/GSE226105_rLog-Normalized_counts.csv.gz',compression='gzip')
dep=dep.rename(columns={dep.columns[0]:'AGI'}); dep['AGI']=dep['AGI'].astype(str).str.upper().str.replace(r'\.[0-9]+$','',regex=True); dep=dep.drop_duplicates('AGI').set_index('AGI')
counts=pd.read_csv(ROOT/'results/gse226105_raw_reanalysis/GSE226105_raw_gene_counts.tsv',sep='\t')
counts=counts.rename(columns={counts.columns[0]:'AGI'}); counts['AGI']=counts['AGI'].astype(str).str.upper().str.replace(r'\.[0-9]+$','',regex=True); counts=counts.groupby('AGI',sort=False).sum().astype(float)
qc=pd.read_csv(ROOT/'results/gse226105_raw_reanalysis/deseq2/GSE226105_count_model_QC.tsv',sep='\t')
sf=dict(zip(qc['sample_key'],qc['size_factor']))
new=pd.DataFrame({g:np.log2(counts[g]/sf[g]+1) for g in meta['gsm']},index=counts.index)
mapcol=dict(zip(meta['gsm'],meta['matrix_column']))
common=new.index.intersection(dep.index)
assert len(common)>20000, len(common)
rows=[]
for gsm in meta['gsm']:
    a=new.loc[common,gsm].to_numpy(); b=dep.loc[common,mapcol[gsm]].to_numpy(float)
    rows.append({'gsm':gsm,'matrix_column':mapcol[gsm],'common_genes':len(common),'pearson':pearsonr(a,b).statistic,'spearman':spearmanr(a,b).statistic})
sample=pd.DataFrame(rows); sample.to_csv(out/'samplewise_raw_vs_deposited_concordance.tsv',sep='\t',index=False)
ctrl=meta.loc[meta.condition=='control','gsm'].tolist(); dr=meta.loc[meta.condition=='drought','gsm'].tolist()
new_eff=new.loc[common,dr].mean(axis=1)-new.loc[common,ctrl].mean(axis=1)
dep_eff=dep.loc[common,[mapcol[x] for x in dr]].mean(axis=1)-dep.loc[common,[mapcol[x] for x in ctrl]].mean(axis=1)
orth=pd.read_csv(ROOT/'inputs/arabidopsis_ortholog_true_drought_evidence.tsv',sep='\t'); ids=pd.Index(orth.AGI.astype(str).str.upper().str.replace(r'\.[0-9]+$','',regex=True).unique()); oi=common.intersection(ids)
summary=pd.DataFrame([
 {'scope':'genomewide_common','n':len(common),'pearson_effect':pearsonr(new_eff,dep_eff).statistic,'spearman_effect':spearmanr(new_eff,dep_eff).statistic},
 {'scope':'prespecified_orthologs','n':len(oi),'pearson_effect':pearsonr(new_eff.loc[oi],dep_eff.loc[oi]).statistic,'spearman_effect':spearmanr(new_eff.loc[oi],dep_eff.loc[oi]).statistic}
]); summary.to_csv(out/'effect_concordance_summary.tsv',sep='\t',index=False)
pd.DataFrame({'AGI':common,'raw_reanalysis_log2norm_difference':new_eff.loc[common].values,'deposited_rlog_difference':dep_eff.loc[common].values}).to_csv(out/'genomewide_effect_concordance.tsv',sep='\t',index=False)
checks={'min_sample_pearson':float(sample.pearson.min()),'min_sample_spearman':float(sample.spearman.min()),'genomewide_effect_spearman':float(summary.loc[summary.scope=='genomewide_common','spearman_effect'].iloc[0]),'common_genes':int(len(common))}
checks['accepted']=checks['min_sample_pearson']>=0.85 and checks['min_sample_spearman']>=0.85 and checks['genomewide_effect_spearman']>=0.70
(out/'CONCORDANCE_ACCEPTANCE.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
if not checks['accepted']: raise RuntimeError(checks)
print('DEPOSITED_MATRIX_CONCORDANCE_ACCEPTED',json.dumps(checks),flush=True)
