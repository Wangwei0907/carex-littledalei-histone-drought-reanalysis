#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
set.seed(20260801)

root <- Sys.getenv("CAREX_SOURCE_ROOT", ".")
lib <- file.path(root, "r_libs")
.libPaths(c(lib, .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(fgsea)
  library(ggplot2)
  library(cowplot)
})

enrich_root <- file.path(root, "enrichment")
ref_dir <- file.path(enrich_root, "reference")
res_dir <- file.path(enrich_root, "results")
fig_dir <- file.path(enrich_root, "figures")
dir.create(ref_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

gaf_path <- file.path(ref_dir, "tair.gaf.gz")
obo_path <- file.path(ref_dir, "go-basic.obo")
stopifnot(file.exists(gaf_path), file.exists(obo_path))

gse226_path <- file.path(
  root, "results", "gse226105_raw_reanalysis", "deseq2",
  "GSE226105_genomewide_DESeq2_results.tsv"
)
gse243_path <- file.path(
  root, "external_gse243365", "results",
  "GSE243365_genomewide_DESeq2.tsv"
)
stopifnot(file.exists(gse226_path), file.exists(gse243_path))

write_tsv <- function(x, name) {
  fwrite(x, file.path(res_dir, name), sep = "\t", quote = FALSE, na = "")
}

message("Parsing GO ontology")
obo <- readLines(obo_path, warn = FALSE)
starts <- which(obo == "[Term]")
ends <- c(starts[-1L] - 1L, length(obo))
term_rows <- vector("list", length(starts))
parent_map <- vector("list", length(starts))
names(parent_map) <- rep("", length(starts))
for (i in seq_along(starts)) {
  block <- obo[starts[i]:ends[i]]
  id_line <- grep("^id: GO:", block, value = TRUE)
  if (!length(id_line)) next
  go_id <- sub("^id: ", "", id_line[1L])
  name_line <- grep("^name: ", block, value = TRUE)
  ns_line <- grep("^namespace: ", block, value = TRUE)
  obsolete <- any(block == "is_obsolete: true")
  is_a <- sub("^is_a: (GO:[0-9]+).*$", "\\1",
              grep("^is_a: GO:", block, value = TRUE))
  part_of <- sub("^relationship: part_of (GO:[0-9]+).*$", "\\1",
                 grep("^relationship: part_of GO:", block, value = TRUE))
  term_rows[[i]] <- data.table(
    GO_ID = go_id,
    GO_term = if (length(name_line)) sub("^name: ", "", name_line[1L]) else "",
    namespace = if (length(ns_line)) sub("^namespace: ", "", ns_line[1L]) else "",
    is_obsolete = obsolete
  )
  parent_map[[i]] <- unique(c(is_a, part_of))
  names(parent_map)[i] <- go_id
}
term_info <- rbindlist(term_rows, fill = TRUE)
parent_map <- parent_map[nzchar(names(parent_map))]
bp_info <- term_info[namespace == "biological_process" & !is_obsolete]
bp_ids <- bp_info$GO_ID
bp_name <- setNames(bp_info$GO_term, bp_info$GO_ID)
stopifnot(length(bp_ids) > 10000L)

message("Reading TAIR GAF")
gaf <- as.data.table(read.delim(
  gzfile(gaf_path),
  sep = "\t", header = FALSE, fill = TRUE, quote = "",
  comment.char = "!", check.names = FALSE
))
stopifnot(ncol(gaf) >= 15L)
gaf <- unique(gaf[
  V9 == "P" & !grepl("NOT", V4, fixed = TRUE),
  .(AGI = toupper(V2), GO_ID = V5)
])
gaf <- gaf[grepl("^AT[1-5MC]G[0-9]{5}$", AGI) & GO_ID %in% bp_ids]

g226 <- fread(gse226_path)
g243 <- fread(gse243_path)
for (x in list(g226, g243)) {
  stopifnot(all(c("AGI", "stat", "padj", "log2FoldChange") %in% names(x)))
}
g226[, AGI := toupper(AGI)]
g243[, AGI := toupper(AGI)]
universe_union <- union(g226[is.finite(stat), AGI], g243[is.finite(stat), AGI])
gaf <- gaf[AGI %in% universe_union]

message("Propagating GO annotations to is_a/part_of ancestors")
ancestor_cache <- new.env(hash = TRUE, parent = emptyenv())
ancestors <- function(go_id, trail = character()) {
  if (exists(go_id, envir = ancestor_cache, inherits = FALSE)) {
    return(get(go_id, envir = ancestor_cache, inherits = FALSE))
  }
  if (go_id %in% trail) return(go_id)
  parents <- parent_map[[go_id]]
  parents <- parents[parents %in% bp_ids]
  answer <- go_id
  if (length(parents)) {
    answer <- unique(c(
      go_id,
      unlist(lapply(parents, ancestors, trail = c(trail, go_id)), use.names = FALSE)
    ))
  }
  assign(go_id, answer, envir = ancestor_cache)
  answer
}

by_gene <- split(gaf$GO_ID, gaf$AGI)
propagated <- rbindlist(lapply(names(by_gene), function(gene) {
  terms <- unique(unlist(lapply(unique(by_gene[[gene]]), ancestors), use.names = FALSE))
  data.table(AGI = gene, GO_ID = terms)
}))
propagated <- unique(propagated[GO_ID %in% bp_ids])
pathways <- split(propagated$AGI, propagated$GO_ID)
pathways <- lapply(pathways, unique)

gmt_lines <- vapply(names(pathways), function(go_id) {
  paste(c(go_id, bp_name[[go_id]], sort(pathways[[go_id]])), collapse = "\t")
}, character(1))
writeLines(gmt_lines, file.path(ref_dir, "TAIR_GO_BP_propagated_20260801.gmt"))

make_ranks <- function(x) {
  y <- x[is.finite(stat) & !is.na(AGI), .(AGI, stat)]
  y <- y[!duplicated(AGI)]
  ranks <- y$stat
  names(ranks) <- y$AGI
  sort(ranks, decreasing = TRUE)
}
ranks226 <- make_ranks(g226)
ranks243 <- make_ranks(g243)
stopifnot(length(ranks226) == 18062L, length(ranks243) == 16243L)

run_gsea <- function(ranks, dataset) {
  set.seed(20260801)
  fg <- fgseaMultilevel(
    pathways = pathways,
    stats = ranks,
    minSize = 15,
    maxSize = 500,
    eps = 0,
    scoreType = "std",
    nproc = 1
  )
  fg <- as.data.table(fg)
  fg[, dataset := dataset]
  fg[, GO_ID := pathway]
  fg[, GO_term := unname(bp_name[GO_ID])]
  fg[, leadingEdge := vapply(leadingEdge, paste, collapse = "/", character(1))]
  setcolorder(fg, c(
    "dataset", "GO_ID", "GO_term", "size", "ES", "NES", "pval", "padj",
    "log2err", "leadingEdge"
  ))
  fg[order(padj, -abs(NES))]
}

message("Running preranked GSEA")
fg226 <- run_gsea(ranks226, "GSE226105")
fg243 <- run_gsea(ranks243, "GSE243365")
write_tsv(fg226, "GSE226105_GO_BP_fgsea.tsv")
write_tsv(fg243, "GSE243365_GO_BP_fgsea.tsv")

run_ora <- function(de, dataset) {
  universe <- unique(de[is.finite(stat), AGI])
  formal <- de[!is.na(padj) & padj < 0.05 & abs(log2FoldChange) >= 1]
  out <- rbindlist(lapply(c("Up", "Down"), function(direction) {
    selected <- unique(formal[
      if (direction == "Up") log2FoldChange >= 1 else log2FoldChange <= -1,
      AGI
    ])
    rows <- rbindlist(lapply(names(pathways), function(go_id) {
      members <- intersect(pathways[[go_id]], universe)
      if (length(members) < 10L || length(members) > 500L) return(NULL)
      overlap <- intersect(members, selected)
      if (!length(overlap)) return(NULL)
      p <- phyper(
        length(overlap) - 1L,
        length(members),
        length(universe) - length(members),
        length(selected),
        lower.tail = FALSE
      )
      data.table(
        dataset = dataset,
        direction = direction,
        GO_ID = go_id,
        GO_term = unname(bp_name[go_id]),
        universe_size = length(universe),
        selected_size = length(selected),
        term_size = length(members),
        overlap_size = length(overlap),
        gene_ratio = length(overlap) / length(selected),
        background_ratio = length(members) / length(universe),
        enrichment_ratio = (length(overlap) / length(selected)) /
          (length(members) / length(universe)),
        pvalue = p,
        overlap_genes = paste(sort(overlap), collapse = "/")
      )
    }))
    rows[, padj := p.adjust(pvalue, method = "BH")]
    rows
  }))
  out[order(padj, -enrichment_ratio)]
}

message("Running direction-stratified ORA")
ora226 <- run_ora(g226, "GSE226105")
ora243 <- run_ora(g243, "GSE243365")
write_tsv(ora226, "GSE226105_GO_BP_ORA.tsv")
write_tsv(ora243, "GSE243365_GO_BP_ORA.tsv")

message("Building cross-dataset consensus")
consensus <- merge(
  fg226,
  fg243,
  by = c("GO_ID", "GO_term"),
  suffixes = c("_GSE226105", "_GSE243365")
)
consensus[, same_direction := sign(NES_GSE226105) == sign(NES_GSE243365)]
consensus[, consensus_FDR_005 :=
  same_direction & padj_GSE226105 < 0.05 & padj_GSE243365 < 0.05]
consensus[, direction := fifelse(NES_GSE226105 > 0, "Positive", "Negative")]
consensus[, conjunction_FDR := pmax(padj_GSE226105, padj_GSE243365)]
consensus[, NES_difference := NES_GSE243365 - NES_GSE226105]
consensus[, combined_abs_NES := abs(NES_GSE226105 + NES_GSE243365)]
setorder(consensus, -consensus_FDR_005, conjunction_FDR, -combined_abs_NES)
write_tsv(consensus, "GSE226105_GSE243365_GO_BP_GSEA_consensus.tsv")

jaccard <- function(a, b) {
  u <- union(a, b)
  if (!length(u)) return(0)
  length(intersect(a, b)) / length(u)
}
select_representatives <- function(x, dir_value, n = 6L, cutoff = 0.5) {
  candidates <- x[consensus_FDR_005 & direction == dir_value]
  setorder(candidates, conjunction_FDR, -combined_abs_NES)
  selected <- character()
  for (go_id in candidates$GO_ID) {
    if (!length(selected) || all(vapply(
      selected,
      function(other) jaccard(pathways[[go_id]], pathways[[other]]) < cutoff,
      logical(1)
    ))) {
      selected <- c(selected, go_id)
    }
    if (length(selected) >= n) break
  }
  candidates[GO_ID %in% selected][match(selected, GO_ID)]
}

representatives <- rbindlist(list(
  select_representatives(consensus, "Positive"),
  select_representatives(consensus, "Negative")
), fill = TRUE)
representatives[, display_order := seq_len(.N)]
write_tsv(representatives, "GO_BP_GSEA_consensus_representative_terms.tsv")

parse_le <- function(x) {
  if (is.na(x) || !nzchar(x)) character() else strsplit(x, "/", fixed = TRUE)[[1L]]
}
leading_rows <- rbindlist(lapply(seq_len(nrow(representatives)), function(i) {
  row <- representatives[i]
  le226 <- parse_le(row$leadingEdge_GSE226105)
  le243 <- parse_le(row$leadingEdge_GSE243365)
  genes <- union(le226, le243)
  data.table(
    GO_ID = row$GO_ID,
    GO_term = row$GO_term,
    direction = row$direction,
    AGI = genes,
    leading_edge_GSE226105 = genes %in% le226,
    leading_edge_GSE243365 = genes %in% le243,
    leading_edge_both = genes %in% intersect(le226, le243)
  )
}))
write_tsv(leading_rows, "GO_BP_representative_leading_edge_membership.tsv")

gene_recurrence <- leading_rows[, .(
  representative_terms = uniqueN(GO_ID),
  leading_edge_terms_GSE226105 = sum(leading_edge_GSE226105),
  leading_edge_terms_GSE243365 = sum(leading_edge_GSE243365),
  leading_edge_terms_both = sum(leading_edge_both)
), by = AGI]
gene_recurrence <- merge(
  gene_recurrence,
  g226[, .(AGI, stat_GSE226105 = stat, log2FC_GSE226105 = log2FoldChange,
           padj_GSE226105 = padj)],
  by = "AGI", all.x = TRUE
)
gene_recurrence <- merge(
  gene_recurrence,
  g243[, .(AGI, stat_GSE243365 = stat, log2FC_GSE243365 = log2FoldChange,
           padj_GSE243365 = padj)],
  by = "AGI", all.x = TRUE
)
setorder(gene_recurrence, -leading_edge_terms_both, -representative_terms, AGI)
write_tsv(gene_recurrence, "GO_BP_leading_edge_gene_recurrence.tsv")

term_sizes <- rbindlist(lapply(names(pathways), function(go_id) {
  data.table(
    GO_ID = go_id,
    GO_term = unname(bp_name[go_id]),
    genes_total_union = length(intersect(pathways[[go_id]], universe_union)),
    genes_GSE226105 = length(intersect(pathways[[go_id]], names(ranks226))),
    genes_GSE243365 = length(intersect(pathways[[go_id]], names(ranks243)))
  )
}))
write_tsv(term_sizes, "TAIR_GO_BP_propagated_term_sizes.tsv")

facts <- data.table(
  metric = c(
    "GO_BP_terms_in_ontology",
    "GAF_BP_direct_gene_term_pairs_in_union",
    "propagated_gene_term_pairs_in_union",
    "GSE226105_ranked_genes",
    "GSE243365_ranked_genes",
    "GSE226105_tested_GSEA_terms",
    "GSE243365_tested_GSEA_terms",
    "GSE226105_FDR005_GSEA_terms",
    "GSE243365_FDR005_GSEA_terms",
    "consensus_same_direction_FDR005_terms",
    "representative_consensus_terms",
    "GSE226105_formal_up_genes",
    "GSE226105_formal_down_genes",
    "GSE243365_formal_up_genes",
    "GSE243365_formal_down_genes",
    "GSE226105_FDR005_ORA_terms",
    "GSE243365_FDR005_ORA_terms"
  ),
  value = c(
    length(bp_ids),
    nrow(gaf),
    nrow(propagated),
    length(ranks226),
    length(ranks243),
    nrow(fg226),
    nrow(fg243),
    sum(fg226$padj < 0.05, na.rm = TRUE),
    sum(fg243$padj < 0.05, na.rm = TRUE),
    sum(consensus$consensus_FDR_005, na.rm = TRUE),
    nrow(representatives),
    g226[!is.na(padj) & padj < 0.05 & log2FoldChange >= 1, .N],
    g226[!is.na(padj) & padj < 0.05 & log2FoldChange <= -1, .N],
    g243[!is.na(padj) & padj < 0.05 & log2FoldChange >= 1, .N],
    g243[!is.na(padj) & padj < 0.05 & log2FoldChange <= -1, .N],
    sum(ora226$padj < 0.05, na.rm = TRUE),
    sum(ora243$padj < 0.05, na.rm = TRUE)
  )
)
write_tsv(facts, "BULK_GO_ENRICHMENT_ANALYSIS_FACTS.tsv")

writeLines(c(
  sprintf("PASS GSE226105_ranked_genes=%d", length(ranks226)),
  sprintf("PASS GSE243365_ranked_genes=%d", length(ranks243)),
  sprintf("PASS GSE226105_tested_terms=%d", nrow(fg226)),
  sprintf("PASS GSE243365_tested_terms=%d", nrow(fg243)),
  sprintf("PASS consensus_terms=%d", sum(consensus$consensus_FDR_005)),
  sprintf("PASS representative_terms=%d", nrow(representatives)),
  "PASS GSEA_rank_metric=DESeq2_Wald_statistic",
  "PASS GSEA_minSize=15_maxSize=500_eps=0",
  "PASS ORA_background=dataset_specific_modeled_genes",
  "PASS ORA_gene_rule=padj_lt_0.05_and_abs_unshrunken_log2FC_ge_1",
  "PASS GO_namespace=biological_process",
  "PASS GO_propagation=is_a_and_part_of"
), file.path(res_dir, "BULK_GO_ENRICHMENT_ACCEPTANCE.txt"))

writeLines(capture.output(sessionInfo()), file.path(res_dir, "BULK_GO_ENRICHMENT_sessionInfo.txt"))
system2("sha256sum", c(shQuote(gaf_path), shQuote(obo_path)),
        stdout = file.path(ref_dir, "GO_REFERENCE_SHA256SUMS.txt"))
system2("sha256sum", list.files(res_dir, full.names = TRUE),
        stdout = file.path(enrich_root, "ENRICHMENT_RESULTS_SHA256SUMS.txt"))

cat("ANALYSIS_FACTS\n")
print(facts)
cat("REPRESENTATIVE_TERMS\n")
print(representatives[, .(
  GO_ID, GO_term, direction, NES_GSE226105, padj_GSE226105,
  NES_GSE243365, padj_GSE243365, conjunction_FDR
)])
