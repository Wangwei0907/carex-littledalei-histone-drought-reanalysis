#!/usr/bin/env Rscript

# Server-only formal reanalysis of the prespecified six-sample GSE226105 contrast.
# This script starts from an integer gene-count matrix produced on the Linux server.
# It must not be used on the deposited rLog matrix.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 4L) {
  stop(
    "Usage: Rscript server_gse226105_deseq2.R counts.tsv sample_metadata.tsv ",
    "arabidopsis_ortholog_true_drought_evidence.tsv out_dir [sample_key=gsm] ",
    "[min_count=10] [min_samples=3]"
  )
}

counts_path <- args[[1L]]
metadata_path <- args[[2L]]
ortholog_path <- args[[3L]]
out_dir <- args[[4L]]
sample_key <- if (length(args) >= 5L) args[[5L]] else "gsm"
min_count <- if (length(args) >= 6L) as.integer(args[[6L]]) else 10L
min_samples <- if (length(args) >= 7L) as.integer(args[[7L]]) else 3L

dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
stopifnot(requireNamespace("DESeq2", quietly = TRUE))

read_tsv <- function(path) {
  read.delim(
    path,
    header = TRUE,
    sep = "\t",
    quote = "",
    comment.char = "",
    check.names = FALSE,
    stringsAsFactors = FALSE
  )
}

write_tsv <- function(x, name) {
  write.table(
    x,
    file = file.path(out_dir, name),
    sep = "\t",
    quote = FALSE,
    row.names = FALSE,
    na = ""
  )
}

normalize_agi <- function(x) {
  sub("\\.[0-9]+$", "", toupper(trimws(as.character(x))))
}

meta <- read_tsv(metadata_path)
required_meta <- c(sample_key, "sample_id", "condition", "replicate", "gsm", "srx")
missing_meta <- setdiff(required_meta, colnames(meta))
if (length(missing_meta)) stop("Missing metadata columns: ", paste(missing_meta, collapse = ", "))
if (nrow(meta) != 6L) stop("Expected exactly six prespecified samples; observed ", nrow(meta))
if (anyDuplicated(meta[[sample_key]])) stop("Duplicate sample keys in metadata")
if (!identical(sort(unique(meta$condition)), c("control", "drought"))) {
  stop("Condition must contain only control and drought")
}
if (!all(table(meta$condition) == 3L)) stop("Expected three biological replicates per condition")

raw <- read_tsv(counts_path)
if (ncol(raw) < 7L) stop("Count matrix must contain one gene column and six sample columns")
gene_ids <- normalize_agi(raw[[1L]])
if (any(!nzchar(gene_ids))) stop("Blank gene identifier after normalization")

sample_keys <- as.character(meta[[sample_key]])
missing_count_cols <- setdiff(sample_keys, colnames(raw))
if (length(missing_count_cols)) {
  stop("Count matrix lacks prespecified columns: ", paste(missing_count_cols, collapse = ", "))
}

count_df <- raw[, sample_keys, drop = FALSE]
count_mat <- as.matrix(data.frame(lapply(count_df, as.numeric), check.names = FALSE))
colnames(count_mat) <- sample_keys
if (anyNA(count_mat) || any(!is.finite(count_mat))) stop("Non-finite count value detected")
if (any(count_mat < 0)) stop("Negative count value detected")
if (any(abs(count_mat - round(count_mat)) > 1e-8)) stop("Input must be integer counts")
storage.mode(count_mat) <- "integer"

# Sum rows only when version stripping creates duplicate AGI identifiers.
count_mat <- rowsum(count_mat, group = gene_ids, reorder = FALSE)
meta <- meta[match(colnames(count_mat), meta[[sample_key]]), , drop = FALSE]
rownames(meta) <- meta[[sample_key]]
meta$condition <- factor(meta$condition, levels = c("control", "drought"))

orth <- read_tsv(ortholog_path)
if (!("AGI" %in% colnames(orth))) stop("Ortholog evidence table lacks AGI column")
orth$AGI <- normalize_agi(orth$AGI)
if (anyDuplicated(orth$AGI)) stop("Duplicate AGI identifiers in ortholog evidence table")
orth_ids <- orth$AGI
if (length(orth_ids) != 56L) stop("Expected 56 prespecified ortholog units; observed ", length(orth_ids))
missing_orth <- setdiff(orth_ids, rownames(count_mat))
if (length(missing_orth)) stop("Prespecified orthologs absent from count matrix: ", paste(missing_orth, collapse = ", "))

keep <- rowSums(count_mat >= min_count) >= min_samples
if (!any(keep)) stop("No genes pass the prespecified count filter")
filtered <- count_mat[keep, , drop = FALSE]

dds <- DESeq2::DESeqDataSetFromMatrix(
  countData = filtered,
  colData = meta,
  design = ~ condition
)
dds <- DESeq2::DESeq(dds, quiet = TRUE)
res <- DESeq2::results(dds, contrast = c("condition", "drought", "control"), alpha = 0.05)
res_df <- data.frame(AGI = rownames(res), as.data.frame(res), check.names = FALSE)
res_df$AGI <- normalize_agi(res_df$AGI)

coef_name <- "condition_drought_vs_control"
res_df$log2FoldChange_shrunken <- NA_real_
shrink_status <- "not_run_apeglm_unavailable"
if (requireNamespace("apeglm", quietly = TRUE) && coef_name %in% DESeq2::resultsNames(dds)) {
  shr <- tryCatch(
    DESeq2::lfcShrink(dds, coef = coef_name, type = "apeglm"),
    error = function(e) e
  )
  if (inherits(shr, "error")) {
    shrink_status <- paste0("failed: ", conditionMessage(shr))
  } else {
    shrink_status <- "completed_apeglm"
    res_df$log2FoldChange_shrunken <- shr[match(res_df$AGI, normalize_agi(rownames(shr))), "log2FoldChange"]
  }
}

res_df <- res_df[order(res_df$padj, -abs(res_df$log2FoldChange), na.last = TRUE), , drop = FALSE]
write_tsv(res_df, "GSE226105_genomewide_DESeq2_results.tsv")

orth_res <- merge(
  orth,
  res_df,
  by = "AGI",
  all.x = TRUE,
  sort = FALSE
)
orth_res <- orth_res[match(orth_ids, orth_res$AGI), , drop = FALSE]
orth_res$passes_genomewide_FDR_005 <- !is.na(orth_res$padj) & orth_res$padj < 0.05
orth_res$passes_abs_LFC_1_and_FDR_005 <- orth_res$passes_genomewide_FDR_005 &
  !is.na(orth_res$log2FoldChange) & abs(orth_res$log2FoldChange) >= 1
write_tsv(orth_res, "GSE226105_prespecified_56_ortholog_DESeq2.tsv")

# Apply the size factors estimated from filtered genes to the full count matrix.
# This preserves all 56 prespecified orthologs in the normalized-count export,
# including any ortholog that did not pass the genome-wide model filter.
norm_all <- sweep(count_mat, 2L, DESeq2::sizeFactors(dds), "/")
norm_orth <- data.frame(AGI = orth_ids, norm_all[orth_ids, , drop = FALSE], check.names = FALSE)
write_tsv(norm_orth, "GSE226105_prespecified_56_normalized_counts.tsv")

vsd <- DESeq2::vst(dds, blind = FALSE)
pca <- prcomp(t(SummarizedExperiment::assay(vsd)))
pct <- 100 * pca$sdev^2 / sum(pca$sdev^2)
pca_df <- cbind(
  meta[rownames(pca$x), c("sample_id", "gsm", "srx", "condition", "replicate"), drop = FALSE],
  PC1 = pca$x[, 1L],
  PC2 = pca$x[, 2L]
)
write_tsv(pca_df, "GSE226105_sample_PCA.tsv")

qc <- data.frame(
  sample_key = colnames(count_mat),
  sample_id = meta[colnames(count_mat), "sample_id"],
  condition = as.character(meta[colnames(count_mat), "condition"]),
  raw_library_size = colSums(count_mat),
  filtered_library_size = colSums(filtered),
  size_factor = DESeq2::sizeFactors(dds),
  stringsAsFactors = FALSE
)
write_tsv(qc, "GSE226105_count_model_QC.tsv")

parameters <- data.frame(
  parameter = c(
    "analysis_status", "model", "contrast", "sample_key", "sample_count",
    "replicates_per_group", "gene_count_before_filter", "gene_count_after_filter",
    "min_count", "min_samples", "ortholog_units", "lfc_shrinkage",
    "PCA_PC1_percent", "PCA_PC2_percent"
  ),
  value = c(
    "completed", "~ condition", "drought vs control", sample_key, nrow(meta),
    3L, nrow(count_mat), nrow(filtered), min_count, min_samples, length(orth_ids),
    shrink_status, sprintf("%.6f", pct[[1L]]), sprintf("%.6f", pct[[2L]])
  ),
  stringsAsFactors = FALSE
)
write_tsv(parameters, "GSE226105_analysis_parameters.tsv")

writeLines(capture.output(sessionInfo()), file.path(out_dir, "sessionInfo.txt"))
writeLines(
  c(
    paste("completed_utc", format(Sys.time(), tz = "UTC", usetz = TRUE), sep = "\t"),
    paste("working_directory", normalizePath(getwd()), sep = "\t"),
    paste("counts_input", normalizePath(counts_path), sep = "\t"),
    paste("metadata_input", normalizePath(metadata_path), sep = "\t"),
    paste("ortholog_input", normalizePath(ortholog_path), sep = "\t")
  ),
  file.path(out_dir, "run_manifest.tsv")
)

message("Accepted DESeq2 result generation completed for six samples and 56 ortholog units.")
