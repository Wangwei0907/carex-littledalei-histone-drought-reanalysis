#!/usr/bin/env python3
"""Candidate-focused, proteome-wide-target reciprocal top-hit sensitivity check.

Carex queries are the 84 exact KAF protein accessions used for the curated
crosswalk. Both search databases are complete annotated proteomes. For each
relevant Arabidopsis AGI, all annotated peptide isoforms are searched back
against the complete Carex proteome; reverse hits are collapsed by Carex
locus_tag. This is a ranking diagnostic, not proof of one-to-one orthology.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import re
from collections import defaultdict
from pathlib import Path


CAREX_FASTA = "GCA_011114355.1_ASM1111435v1_protein.faa.gz"
CAREX_GFF = "GCA_011114355.1_ASM1111435v1_genomic.gff.gz"
ARAB_FASTA = "Arabidopsis_thaliana.TAIR10.pep.all.fa.gz"
CURATED_TSV = "strict_histone_modifier_gene_set.tsv"
AGI_RE = re.compile(r"AT[1-5CM]G\d{5}", re.I)


def fasta_records(path: Path):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        header = None
        seq = []
        for line in handle:
            if line.startswith(">"):
                if header is not None:
                    yield header.split()[0], header, "".join(seq)
                header = line[1:].strip()
                seq = []
            else:
                seq.append(line.strip())
        if header is not None:
            yield header.split()[0], header, "".join(seq)


def write_record(handle, header: str, sequence: str):
    handle.write(">" + header + "\n")
    for start in range(0, len(sequence), 80):
        handle.write(sequence[start : start + 80] + "\n")


def curated_rows(task_dir: Path):
    with (task_dir / "input" / CURATED_TSV).open(
        encoding="utf-8", newline=""
    ) as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    if len(rows) != 84:
        raise ValueError(f"Expected 84 curated loci, found {len(rows)}")
    accessions = [row["protein_accession"] for row in rows]
    if len(set(accessions)) != 84:
        raise ValueError("Curated protein accessions are not unique")
    for row in rows:
        match = AGI_RE.search(row["arabidopsis_protein"])
        row["original_AGI"] = match.group(0).upper() if match else ""
    return rows


def arab_peptide_to_gene(task_dir: Path):
    mapping = {}
    for peptide_id, header, _ in fasta_records(task_dir / "input" / ARAB_FASTA):
        match = re.search(r"\bgene:(AT[1-5CM]G\d{5})\b", header, re.I)
        if not match:
            raise ValueError(f"Missing AGI in Arabidopsis header: {header[:120]}")
        mapping[peptide_id] = match.group(1).upper()
    return mapping


def carex_protein_to_locus(task_dir: Path):
    mapping = {}
    with gzip.open(task_dir / "input" / CAREX_GFF, "rt", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9 or fields[2] != "CDS":
                continue
            attrs = dict(part.split("=", 1) for part in fields[8].split(";") if "=" in part)
            protein = attrs.get("protein_id", "")
            locus = attrs.get("locus_tag", "")
            if not protein or not locus:
                continue
            if protein in mapping and mapping[protein] != locus:
                raise ValueError(f"Protein {protein} maps to multiple Carex loci")
            mapping[protein] = locus
    return mapping


def extract_carex(task_dir: Path):
    rows = curated_rows(task_dir)
    wanted = {row["protein_accession"] for row in rows}
    observed = set()
    output = task_dir / "input" / "curated_84_carex_proteins.fa"
    with output.open("w", encoding="utf-8") as dest:
        for protein, header, sequence in fasta_records(task_dir / "input" / CAREX_FASTA):
            if protein in wanted:
                write_record(dest, header, sequence)
                observed.add(protein)
    if observed != wanted:
        raise ValueError(f"Missing Carex proteins: {sorted(wanted - observed)}")
    print(f"Extracted {len(observed)} exact Carex proteins to {output}")


def hit_rows(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        for fields in csv.reader(handle, delimiter="\t"):
            if len(fields) != 12:
                raise ValueError(f"Expected 12 DIAMOND output fields in {path}")
            yield {
                "query": fields[0],
                "subject": fields[1],
                "identity": float(fields[2]),
                "alignment_length": int(fields[3]),
                "query_length": int(fields[4]),
                "subject_length": int(fields[5]),
                "query_start": int(fields[6]),
                "query_end": int(fields[7]),
                "subject_start": int(fields[8]),
                "subject_end": int(fields[9]),
                "evalue": float(fields[10]),
                "bitscore": float(fields[11]),
            }


def score_key(hit):
    return (hit["bitscore"], -hit["evalue"], hit["identity"])


def forward_gene_hits(task_dir: Path, peptide_gene: dict[str, str]):
    hits = defaultdict(dict)
    for hit in hit_rows(task_dir / "output" / "carex_to_arabidopsis.tsv"):
        gene = peptide_gene.get(hit["subject"])
        if gene is None:
            raise ValueError(f"Unmapped Arabidopsis peptide: {hit['subject']}")
        existing = hits[hit["query"]].get(gene)
        if existing is None or score_key(hit) > score_key(existing):
            hits[hit["query"]][gene] = hit
    return {
        query: sorted(gene_hits.items(), key=lambda x: (-x[1]["bitscore"], x[1]["evalue"], x[0]))
        for query, gene_hits in hits.items()
    }


def extract_arabidopsis(task_dir: Path):
    rows = curated_rows(task_dir)
    peptide_gene = arab_peptide_to_gene(task_dir)
    forward = forward_gene_hits(task_dir, peptide_gene)
    wanted = {row["original_AGI"] for row in rows if row["original_AGI"]}
    for row in rows:
        ranked = forward.get(row["protein_accession"], [])
        if ranked:
            wanted.add(ranked[0][0])
    observed = set()
    proteins = 0
    output = task_dir / "input" / "relevant_arabidopsis_isoforms.fa"
    with output.open("w", encoding="utf-8") as dest:
        for protein, header, sequence in fasta_records(task_dir / "input" / ARAB_FASTA):
            gene = peptide_gene[protein]
            if gene in wanted:
                write_record(dest, header, sequence)
                observed.add(gene)
                proteins += 1
    if observed != wanted:
        raise ValueError(f"Missing Arabidopsis genes: {sorted(wanted - observed)}")
    print(f"Extracted {proteins} isoforms from {len(wanted)} AGIs to {output}")


def reverse_gene_hits(task_dir: Path, peptide_gene: dict[str, str], carex_locus: dict[str, str]):
    hits = defaultdict(dict)
    for hit in hit_rows(task_dir / "output" / "arabidopsis_to_carex.tsv"):
        gene = peptide_gene.get(hit["query"])
        locus = carex_locus.get(hit["subject"])
        if gene is None or locus is None:
            raise ValueError(f"Unmapped reverse hit: {hit['query']} -> {hit['subject']}")
        existing = hits[gene].get(locus)
        if existing is None or score_key(hit) > score_key(existing):
            hits[gene][locus] = hit
    return {
        gene: sorted(locus_hits.items(), key=lambda x: (-x[1]["bitscore"], x[1]["evalue"], x[0]))
        for gene, locus_hits in hits.items()
    }


def summarize(task_dir: Path):
    rows = curated_rows(task_dir)
    peptide_gene = arab_peptide_to_gene(task_dir)
    carex_locus = carex_protein_to_locus(task_dir)
    for row in rows:
        accession = row["protein_accession"]
        if carex_locus.get(accession) != row["FCM_ID"]:
            raise ValueError(f"Curated locus mismatch for {accession}")
    forward = forward_gene_hits(task_dir, peptide_gene)
    reverse = reverse_gene_hits(task_dir, peptide_gene, carex_locus)
    fields = [
        "gene", "FCM_ID", "protein_accession", "original_AGI",
        "forward_best_AGI", "forward_best_bitscore", "forward_best_identity_pct",
        "forward_best_evalue", "forward_query_coverage_pct", "forward_subject_coverage_pct",
        "forward_second_AGI", "forward_score_margin_pct", "original_AGI_forward_rank",
        "original_AGI_forward_bitscore", "reverse_best_Carex_locus_for_forward_AGI",
        "reverse_best_Carex_locus_for_original_AGI", "forward_supports_original_crosswalk",
        "reciprocal_top_hit_for_original_crosswalk", "reciprocal_top_hit_for_forward_pair",
    ]
    results = []
    for row in rows:
        accession = row["protein_accession"]
        original = row["original_AGI"]
        ranked = forward.get(accession, [])
        best_gene, best_hit = ranked[0] if ranked else ("", None)
        second_gene, second_hit = ranked[1] if len(ranked) > 1 else ("", None)
        orig_hit = next((hit for gene, hit in ranked if gene == original), None)
        orig_rank = next((i for i, (gene, _) in enumerate(ranked, 1) if gene == original), None)
        rev_best_forward = reverse.get(best_gene, [])[0][0] if reverse.get(best_gene) else ""
        rev_best_original = reverse.get(original, [])[0][0] if reverse.get(original) else ""
        result = {
            "gene": row["gene"],
            "FCM_ID": row["FCM_ID"],
            "protein_accession": accession,
            "original_AGI": original,
            "forward_best_AGI": best_gene,
            "forward_best_bitscore": best_hit["bitscore"] if best_hit else "",
            "forward_best_identity_pct": best_hit["identity"] if best_hit else "",
            "forward_best_evalue": best_hit["evalue"] if best_hit else "",
            "forward_query_coverage_pct": round(100 * (best_hit["query_end"] - best_hit["query_start"] + 1) / best_hit["query_length"], 1) if best_hit else "",
            "forward_subject_coverage_pct": round(100 * (best_hit["subject_end"] - best_hit["subject_start"] + 1) / best_hit["subject_length"], 1) if best_hit else "",
            "forward_second_AGI": second_gene,
            "forward_score_margin_pct": round(100 * (1 - second_hit["bitscore"] / best_hit["bitscore"]), 1) if best_hit and second_hit else "",
            "original_AGI_forward_rank": orig_rank if orig_rank is not None else ("not_in_top_100" if original else "unmapped"),
            "original_AGI_forward_bitscore": orig_hit["bitscore"] if orig_hit else "",
            "reverse_best_Carex_locus_for_forward_AGI": rev_best_forward,
            "reverse_best_Carex_locus_for_original_AGI": rev_best_original,
            "forward_supports_original_crosswalk": bool(original and best_gene == original),
            "reciprocal_top_hit_for_original_crosswalk": bool(original and best_gene == original and rev_best_original == row["FCM_ID"]),
            "reciprocal_top_hit_for_forward_pair": bool(best_gene and rev_best_forward == row["FCM_ID"]),
        }
        results.append(result)
    output = task_dir / "output" / "curated_84_reciprocal_top_hits.tsv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
        writer.writeheader()
        writer.writerows(results)
    mapped = [r for r in results if r["original_AGI"]]
    stats = {
        "curated_loci": len(results),
        "originally_mapped_loci": len(mapped),
        "original_unique_AGIs": len({r["original_AGI"] for r in mapped}),
        "forward_matches_original_crosswalk": sum(r["forward_supports_original_crosswalk"] for r in mapped),
        "reciprocal_top_hits_original_crosswalk": sum(r["reciprocal_top_hit_for_original_crosswalk"] for r in mapped),
        "reciprocal_top_hits_forward_pair": sum(r["reciprocal_top_hit_for_forward_pair"] for r in results),
        "carex_reference_proteins_with_locus_mapping": len(carex_locus),
        "arabidopsis_reference_peptides_with_AGI_mapping": len(peptide_gene),
    }
    with (task_dir / "output" / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(stats, handle, indent=2)
    print(json.dumps(stats, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["extract-carex", "extract-arabidopsis", "summarize"])
    parser.add_argument("task_dir", type=Path)
    args = parser.parse_args()
    {"extract-carex": extract_carex, "extract-arabidopsis": extract_arabidopsis, "summarize": summarize}[args.stage](args.task_dir)


if __name__ == "__main__":
    main()
