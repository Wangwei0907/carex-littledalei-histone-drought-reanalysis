#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)

source_root <- Sys.getenv("CAREX_SOURCE_ROOT", ".")
canonical_file <- Sys.getenv(
  "CAREX_CANONICAL_GO_FILE",
  file.path(source_root, "results", "GO_exact93_canonical_set.tsv")
)
task_root <- Sys.getenv("CAREX_R3_TASK_ROOT")
if (!nzchar(task_root) || !dir.exists(task_root)) {
  stop("CAREX_R3_TASK_ROOT must name the existing task directory")
}
result_dir <- file.path(task_root, "results")
dir.create(result_dir, showWarnings = FALSE)

.libPaths(c(file.path(source_root, "r_libs"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(DESeq2)
  library(fgsea)
})

canonical <- fread(canonical_file)
stopifnot(
  nrow(canonical) == 93L,
  !anyDuplicated(canonical$GO_ID),
  all(canonical$exact_canonical93),
  all(sign(canonical$exact_NES_226) == sign(canonical$exact_NES_243))
)
canonical[, full_consensus_direction := sign(exact_NES_226)]

gmt_file <- file.path(source_root, "enrichment", "reference",
                      "TAIR_GO_BP_propagated_20260801.gmt")
gmt_parts <- strsplit(readLines(gmt_file, warn = FALSE), "\t", fixed = TRUE)
pathways <- setNames(
  lapply(gmt_parts, function(row) unique(row[-c(1L, 2L)])),
  vapply(gmt_parts, `[[`, character(1), 1L)
)
stopifnot(all(canonical$GO_ID %in% names(pathways)))

read_gse226_counts <- function() {
  x <- fread(file.path(source_root, "results", "gse226105_raw_reanalysis",
                       "GSE226105_raw_gene_counts.tsv"))
  meta <- fread(file.path(source_root, "metadata",
                          "GSE226105_PRESPECIFIED_SAMPLES.tsv"))
  gsm_cols <- meta$gsm
  counts <- as.matrix(x[, ..gsm_cols])
  rownames(counts) <- x$Geneid
  colnames(counts) <- meta$gsm
  storage.mode(counts) <- "integer"
  stopifnot(ncol(counts) == 6L, sum(meta$condition == "drought") == 3L)
  list(counts = counts, condition = meta$condition)
}

read_gse243_counts <- function() {
  manifest <- fread(file.path(source_root, "external_gse243365", "metadata",
                              "download_manifest.tsv"))
  pieces <- lapply(file.path(source_root, "external_gse243365", "raw_counts",
                             manifest$file), function(path) {
    x <- fread(cmd = paste("gzip -dc", shQuote(path)), skip = 1L,
               showProgress = FALSE)
    data.table(Geneid = x[[1L]], count = as.integer(x[[ncol(x)]]))
  })
  ids <- pieces[[1L]]$Geneid
  stopifnot(all(vapply(pieces, function(x) identical(x$Geneid, ids), logical(1))))
  counts <- do.call(cbind, lapply(pieces, `[[`, "count"))
  rownames(counts) <- ids
  colnames(counts) <- manifest$gsm
  storage.mode(counts) <- "integer"
  stopifnot(ncol(counts) == 6L, sum(manifest$condition == "drought") == 3L)
  list(counts = counts, condition = manifest$condition)
}

run_one_dataset <- function(dataset, obj, dataset_index) {
  keep_gene <- rowSums(obj$counts >= 10L) >= 3L
  counts_model <- obj$counts[keep_gene, , drop = FALSE]
  condition <- factor(obj$condition, levels = c("control", "drought"))
  coldata <- data.frame(condition = condition, row.names = colnames(counts_model))
  target <- canonical[, .(GO_ID, GO_term, full_consensus_direction)]

  rbindlist(lapply(seq_len(ncol(counts_model)), function(omit) {
    message(dataset, ": omitting ", colnames(counts_model)[omit])
    keep_sample <- seq_len(ncol(counts_model)) != omit
    dds <- DESeqDataSetFromMatrix(
      counts_model[, keep_sample, drop = FALSE],
      coldata[keep_sample, , drop = FALSE], ~ condition
    )
    dds <- DESeq(dds, quiet = TRUE)
    result <- as.data.table(as.data.frame(results(
      dds, contrast = c("condition", "drought", "control"), alpha = 0.05
    )), keep.rownames = "AGI")
    ranks_dt <- result[is.finite(stat), .(AGI, stat)]
    ranks_dt <- ranks_dt[!duplicated(AGI)]
    ranks <- ranks_dt$stat
    names(ranks) <- ranks_dt$AGI
    ranks <- sort(ranks, decreasing = TRUE)
    run_seed <- 20260801L + dataset_index * 100L + omit
    set.seed(run_seed)
    fg_all <- as.data.table(fgseaMultilevel(
      pathways = pathways, stats = ranks,
      minSize = 15L, maxSize = 500L, eps = 1e-10,
      scoreType = "std", nproc = 1L
    ))
    fg_all[, GO_ID := pathway]
    joined <- merge(target, fg_all[, .(GO_ID, size, NES, pval, padj)],
                    by = "GO_ID", all.x = TRUE, sort = FALSE)
    joined[, `:=`(
      dataset = dataset,
      omitted_sample = colnames(counts_model)[omit],
      run_seed = run_seed,
      full_universe_adjustment_family_n = nrow(fg_all),
      eligible_in_loo = is.finite(NES) & is.finite(padj),
      direction_matches_full = is.finite(NES) &
        sign(NES) == full_consensus_direction,
      FDR005_retained = is.finite(padj) & padj < 0.05
    )]
    joined[, .(dataset, omitted_sample, run_seed, GO_ID, GO_term,
               full_consensus_direction, size, NES, pval, padj,
               full_universe_adjustment_family_n, eligible_in_loo,
               direction_matches_full, FDR005_retained)]
  }), use.names = TRUE)
}

message("Running canonical 93-term leave-one-sample-out GSEA")
long <- rbindlist(list(
  run_one_dataset("GSE226105", read_gse226_counts(), 1L),
  run_one_dataset("GSE243365", read_gse243_counts(), 2L)
))
stopifnot(nrow(long) == 93L * 6L * 2L)

summary <- long[, .(
  leave_one_out_runs = .N,
  eligible_runs = sum(eligible_in_loo),
  min_adjustment_family_n = min(full_universe_adjustment_family_n),
  max_adjustment_family_n = max(full_universe_adjustment_family_n),
  direction_matches_full_n = sum(direction_matches_full),
  direction_stability_fraction = sum(direction_matches_full) / .N,
  FDR005_retained_n = sum(FDR005_retained),
  FDR005_retained_fraction = sum(FDR005_retained) / .N,
  min_NES = if (any(eligible_in_loo)) min(NES[eligible_in_loo]) else NA_real_,
  max_NES = if (any(eligible_in_loo)) max(NES[eligible_in_loo]) else NA_real_
), by = .(dataset, GO_ID, GO_term, full_consensus_direction)]
stopifnot(nrow(summary) == 93L * 2L, all(summary$leave_one_out_runs == 6L))

fwrite(long, file.path(result_dir, "Canonical93_GO_leave_one_sample_out_GSEA.tsv"),
       sep = "\t", quote = FALSE, na = "")
fwrite(summary,
       file.path(result_dir, "Canonical93_GO_leave_one_sample_out_GSEA_summary.tsv"),
       sep = "\t", quote = FALSE, na = "")
qa <- data.table(
  metric = c("canonical_terms", "long_rows", "summary_rows",
             "datasets", "minimum_adjustment_family_n",
             "maximum_adjustment_family_n", "eligible_rows"),
  value = as.character(c(nrow(canonical), nrow(long), nrow(summary),
                         uniqueN(long$dataset),
                         min(long$full_universe_adjustment_family_n),
                         max(long$full_universe_adjustment_family_n),
                         sum(long$eligible_in_loo)))
)
fwrite(qa, file.path(result_dir, "Canonical93_GO_LOO_QA.tsv"),
       sep = "\t", quote = FALSE)
writeLines(capture.output(sessionInfo()), file.path(result_dir, "sessionInfo.txt"))
message("PASS canonical 93-term leave-one-sample-out GSEA")
