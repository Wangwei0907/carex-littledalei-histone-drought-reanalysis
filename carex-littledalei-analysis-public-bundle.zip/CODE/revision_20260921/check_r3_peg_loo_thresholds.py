#!/usr/bin/env python3
"""Sensitivity of the archived PEG interaction shortlist to LOO cutoffs."""

from __future__ import annotations

import csv
import io
import json
import sys
import zipfile
from collections import defaultdict
from pathlib import Path


BASE = "upstream_completed_reanalysis/results/peg_robustness/"
EFFECT = "accession_time_interaction"
THRESHOLDS = {"75%": 14, "80%": 15, "90%": 17}


def read_table(source: Path, name: str) -> list[dict[str, str]]:
    if source.is_dir():
        content = (source / BASE / name).read_text(encoding="utf-8-sig")
    else:
        with zipfile.ZipFile(source) as archive:
            content = archive.read(BASE + name).decode("utf-8-sig")
    return list(csv.DictReader(io.StringIO(content), delimiter="\t"))


def significant(value: str) -> bool:
    try:
        return float(value) < 0.05
    except (TypeError, ValueError):
        return False


def main(source: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=False)
    summary = [r for r in read_table(source, "peg_robustness_summary.tsv") if r["effect"] == EFFECT]
    loo = [r for r in read_table(source, "peg_leave_one_sample_results.tsv") if r["effect"] == EFFECT]

    if len(summary) != 84 or len(loo) != 84 * 18:
        raise AssertionError(f"Unexpected table sizes: summary={len(summary)}, loo={len(loo)}")

    by_gene: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in loo:
        by_gene[row["gene"]].append(row)

    records = []
    for row in summary:
        gene = row["gene"]
        observations = by_gene[gene]
        if len(observations) != 18 or len({r["omitted_sample"] for r in observations}) != 18:
            raise AssertionError(f"Expected 18 distinct omissions for {gene}")
        count = sum(significant(r["FDR"]) for r in observations)
        if count != int(row["leave_one_out_significant_n"]):
            raise AssertionError(f"LOO count mismatch for {gene}: {count} versus {row['leave_one_out_significant_n']}")
        base_pass = significant(row["full_FDR"]) and significant(row["permutation_FDR"])
        records.append(
            {
                "gene": gene,
                "full_FDR": row["full_FDR"],
                "permutation_FDR": row["permutation_FDR"],
                "loo_significant_n": count,
                "base_pass": base_pass,
            }
        )

    with (output / "peg_interaction_threshold_sensitivity.tsv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t")
        writer.writerow(["gene", "full_FDR", "permutation_FDR", "loo_significant_n", "base_pass", "pass_75pct", "pass_80pct", "pass_90pct"])
        for r in sorted(records, key=lambda x: x["gene"]):
            writer.writerow(
                [r["gene"], r["full_FDR"], r["permutation_FDR"], r["loo_significant_n"], r["base_pass"]]
                + [r["base_pass"] and r["loo_significant_n"] >= minimum for minimum in THRESHOLDS.values()]
            )

    sets = {
        label: sorted(r["gene"] for r in records if r["base_pass"] and r["loo_significant_n"] >= minimum)
        for label, minimum in THRESHOLDS.items()
    }
    if sets["80%"] != ["ClHAC07", "ClHAF01", "ClJMJ04", "ClSDG33", "ClSDG46"]:
        raise AssertionError(f"Canonical five-gene shortlist not reproduced: {sets['80%']}")
    result = {
        "input": source.name,
        "effect": EFFECT,
        "full_model_FDR_rule": "<0.05",
        "permutation_FDR_rule": "<0.05",
        "leave_one_out_total": 18,
        "cutoffs": THRESHOLDS,
        "candidate_sets": sets,
        "candidate_counts": {label: len(genes) for label, genes in sets.items()},
        "summary_rows_checked": len(summary),
        "loo_rows_checked": len(loo),
    }
    (output / "summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: check_r3_peg_loo_thresholds.py archive.zip-or-extracted-root output_dir")
    main(Path(sys.argv[1]), Path(sys.argv[2]))
