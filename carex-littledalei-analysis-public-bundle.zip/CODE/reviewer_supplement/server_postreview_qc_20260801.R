#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(data.table))

root <- Sys.getenv(
  "CAREX_OUTPUT_ROOT",
  "."
)
res <- file.path(root, "results")
read_tsv <- function(name) fread(file.path(res, name), na.strings = c("", "NA"))

meta <- read_tsv("Arabidopsis_56_two_dataset_effect_meta_analysis.tsv")
cloo <- read_tsv("Arabidopsis_56_leave_one_sample_out_results.tsv")
cloo_sum <- read_tsv("Arabidopsis_56_leave_one_sample_out_summary.tsv")
gloo <- read_tsv("Consensus_GO_leave_one_sample_out_GSEA.tsv")
gloo_sum <- read_tsv("Consensus_GO_leave_one_sample_out_GSEA_summary.tsv")
cons <- fread(file.path(
  Sys.getenv(
    "CAREX_SOURCE_ROOT",
    "."
  ),
  "enrichment", "results", "GSE226105_GSE243365_GO_BP_GSEA_consensus.tsv"
))
lab226 <- read_tsv("GSE226105_balanced_label_permutation_GSEA.tsv")
lab243 <- read_tsv("GSE243365_balanced_label_permutation_GSEA.tsv")
peg_qc <- read_tsv("PEG_gene_variance_QC.tsv")

stopifnot(
  nrow(meta) == 56L,
  sum(meta$meta_estimable_two_datasets) == 48L,
  sum(meta$k == 1L) == 8L,
  sum(meta$fixed_FDR005, na.rm = TRUE) == 25L,
  sum(meta$random_FDR005, na.rm = TRUE) == 14L,
  sum(meta$fixed_FDR005 & meta$high_heterogeneity_I2_gt50, na.rm = TRUE) == 12L,
  sum(meta$same_direction_raw, na.rm = TRUE) == 36L,
  nrow(cloo) == 672L,
  sum(cloo$estimable) == 624L,
  nrow(gloo) == 1128L,
  all(gloo$full_universe_adjustment_family_n >= 1329L)
)

obs226 <- lab226[is_observed_allocation == TRUE]
obs243 <- lab243[is_observed_allocation == TRUE]
obs <- merge(
  obs226[, .(GO_ID, NES_226 = NES, padj_226 = padj)],
  obs243[, .(GO_ID, NES_243 = NES, padj_243 = padj)],
  by = "GO_ID"
)
obs[, observed_same_direction_FDR005 :=
      padj_226 < 0.05 & padj_243 < 0.05 & sign(NES_226) == sign(NES_243)]
primary <- cons[consensus_FDR_005 == TRUE & same_direction == TRUE]
primary_ids <- primary$GO_ID
obs_ids <- obs[observed_same_direction_FDR005 == TRUE, GO_ID]
borderline <- merge(
  data.table(GO_ID = setdiff(primary_ids, obs_ids)),
  merge(
    primary[, .(GO_ID, primary_padj_226 = padj_GSE226105,
                primary_padj_243 = padj_GSE243365)],
    obs[, .(GO_ID, rerun_padj_226 = padj_226, rerun_padj_243 = padj_243)],
    by = "GO_ID", all = TRUE
  ),
  by = "GO_ID", all.x = TRUE
)
fwrite(borderline, file.path(res, "GO_exact_rerun_borderline_difference.tsv"), sep = "\t")

core <- meta[AGI %in% c("AT1G32750", "AT1G08620", "AT4G33470")]
fwrite(core, file.path(res, "Core_candidate_fixed_random_effects_QC.tsv"), sep = "\t")

qa <- data.table(
  metric = c(
    "mapped_groups", "two_dataset_estimable_groups", "single_dataset_groups",
    "same_direction_among_complete", "fixed_FDR005", "random_FDR005",
    "fixed_FDR005_I2_gt50", "candidate_LOO_total_rows",
    "candidate_LOO_estimable_rows", "GO_LOO_total_rows",
    "GO_LOO_adjustment_family_min", "GO_LOO_adjustment_family_max",
    "GO_LOO_median_FDR_retention", "GO_LOO_full_FDR_retention_rows",
    "primary_consensus_terms", "exact_rerun_observed_consensus_terms",
    "exact_rerun_primary_terms_not_retained", "PEG_invariant_genes"
  ),
  value = c(
    nrow(meta), sum(meta$meta_estimable_two_datasets), sum(meta$k == 1L),
    sum(meta$same_direction_raw, na.rm = TRUE),
    sum(meta$fixed_FDR005, na.rm = TRUE), sum(meta$random_FDR005, na.rm = TRUE),
    sum(meta$fixed_FDR005 & meta$high_heterogeneity_I2_gt50, na.rm = TRUE),
    nrow(cloo), sum(cloo$estimable), nrow(gloo),
    min(gloo$full_universe_adjustment_family_n),
    max(gloo$full_universe_adjustment_family_n),
    median(gloo_sum$FDR005_retained_fraction),
    sum(gloo_sum$FDR005_retained_fraction == 1),
    length(primary_ids), length(obs_ids), length(setdiff(primary_ids, obs_ids)),
    sum(peg_qc$invariant)
  )
)
fwrite(qa, file.path(res, "POSTREVIEW_QC_SUMMARY.tsv"), sep = "\t")

writeLines(c(
  "PASS 56 mapped groups partition into 48 two-dataset and 8 single-dataset groups",
  "PASS fixed/random-effect significance and I2 flags are internally consistent",
  "PASS candidate LOO contains 672 nominal and 624 estimable rows",
  "PASS GO LOO contains 1128 rows and uses full adjustment families",
  "PASS exact sample-label results are reported separately from the primary 94-term consensus",
  "PASS PEG invariant genes are explicitly identified"
), file.path(res, "POSTREVIEW_QC_ACCEPTANCE.txt"))

print(qa)
print(borderline)
print(core)
