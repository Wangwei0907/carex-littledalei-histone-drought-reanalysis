#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
set.seed(20260801)

root <- Sys.getenv(
  "CAREX_SOURCE_ROOT",
  "."
)
lib <- file.path(root, "r_libs")
.libPaths(c(lib, .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(DESeq2)
  library(fgsea)
})

out_root <- Sys.getenv(
  "CAREX_OUTPUT_ROOT",
  "."
)
res_dir <- file.path(out_root, "results")
fig_source_dir <- file.path(out_root, "figure_sources")
dir.create(res_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(fig_source_dir, recursive = TRUE, showWarnings = FALSE)

write_tsv <- function(x, name, where = res_dir) {
  fwrite(as.data.table(x), file.path(where, name), sep = "\t", quote = FALSE, na = "")
}

message("Reading propagated GO-BP gene sets")
gmt_path <- file.path(root, "enrichment", "reference", "TAIR_GO_BP_propagated_20260801.gmt")
gmt_lines <- readLines(gmt_path, warn = FALSE)
gmt_parts <- strsplit(gmt_lines, "\t", fixed = TRUE)
pathways <- setNames(lapply(gmt_parts, function(x) unique(x[-c(1L, 2L)])),
                     vapply(gmt_parts, `[[`, character(1), 1L))
go_names <- setNames(vapply(gmt_parts, `[[`, character(1), 2L), names(pathways))

## PEG simple contrasts and effect sizes -------------------------------------
message("Computing PEG simple contrasts and effect sizes")
peg <- fread(file.path(root, "inputs", "strict_84_fpkm_matrix.tsv"))
sample_names <- grep("^[KS][015]_[123]$", names(peg), value = TRUE)
stopifnot(nrow(peg) == 84L, length(sample_names) == 18L, !anyDuplicated(peg$gene))

peg_meta <- data.table(
  sample = sample_names,
  accession = sub("^([KS]).*$", "\\1", sample_names),
  time_code = sub("^[KS]([015])_.*$", "\\1", sample_names)
)
peg_meta[, time_h := fifelse(time_code == "0", 0L,
                             fifelse(time_code == "1", 12L, 72L))]
peg_meta[, group := paste(accession, time_h, sep = "_")]

Y <- t(log2(as.matrix(peg[, ..sample_names]) + 1))
rownames(Y) <- sample_names
colnames(Y) <- peg$gene
groups <- c("K_0", "K_12", "K_72", "S_0", "S_12", "S_72")
X <- model.matrix(~ 0 + factor(group, levels = groups), data = peg_meta)
colnames(X) <- groups
fit_coef <- solve(crossprod(X), crossprod(X, Y))
resid <- Y - X %*% fit_coef
df_resid <- nrow(Y) - qr(X)$rank
mse <- colSums(resid^2) / df_resid
xtx_inv <- solve(crossprod(X))

contrast_def <- list(
  S_vs_K_0h = c(-1, 0, 0, 1, 0, 0),
  S_vs_K_12h = c(0, -1, 0, 0, 1, 0),
  S_vs_K_72h = c(0, 0, -1, 0, 0, 1),
  K_12h_vs_0h = c(-1, 1, 0, 0, 0, 0),
  K_72h_vs_0h = c(-1, 0, 1, 0, 0, 0),
  S_12h_vs_0h = c(0, 0, 0, -1, 1, 0),
  S_72h_vs_0h = c(0, 0, 0, -1, 0, 1),
  Interaction_12h = c(1, -1, 0, -1, 1, 0),
  Interaction_72h = c(1, 0, -1, -1, 0, 1)
)

peg_contrasts <- rbindlist(lapply(names(contrast_def), function(label) {
  cvec <- contrast_def[[label]]
  estimate <- as.numeric(cvec %*% fit_coef)
  se <- sqrt(mse * as.numeric(t(cvec) %*% xtx_inv %*% cvec))
  statistic <- estimate / se
  pvalue <- 2 * pt(abs(statistic), df = df_resid, lower.tail = FALSE)
  data.table(
    gene = colnames(Y), contrast = label, estimate_log2_FPKM_plus_1 = estimate,
    SE = se, df = df_resid, statistic = statistic, pvalue = pvalue,
    CI95_low = estimate - qt(0.975, df_resid) * se,
    CI95_high = estimate + qt(0.975, df_resid) * se,
    FDR_within_contrast = p.adjust(pvalue, method = "BH")
  )
}))
peg_contrasts[, estimable := is.finite(SE) & SE > 0 & is.finite(pvalue)]
peg_contrasts[, FDR_global_756 := p.adjust(pvalue, method = "BH")]
write_tsv(peg_contrasts, "PEG_simple_contrasts_effect_sizes.tsv")

peg_variance_qc <- data.table(
  gene = peg$gene,
  variance_log2_FPKM_plus_1 = apply(Y, 2L, var),
  invariant_across_18_samples = apply(Y, 2L, function(v) length(unique(v)) == 1L)
)
write_tsv(peg_variance_qc, "PEG_gene_variance_QC.tsv")

peg_long <- melt(peg, id.vars = "gene", measure.vars = sample_names,
                 variable.name = "sample", value.name = "FPKM")
peg_long[, log2_FPKM_plus_1 := log2(FPKM + 1)]
peg_long <- merge(peg_long, peg_meta[, .(sample, accession, time_h, group)], by = "sample")
peg_summary <- peg_long[, .(
  n = .N, mean_log2_FPKM_plus_1 = mean(log2_FPKM_plus_1),
  SD_log2_FPKM_plus_1 = sd(log2_FPKM_plus_1),
  SE_log2_FPKM_plus_1 = sd(log2_FPKM_plus_1) / sqrt(.N)
), by = .(gene, accession, time_h, group)]
write_tsv(peg_summary, "PEG_group_expression_summary.tsv")

stable <- fread(file.path(root, "results", "peg_robustness", "peg_stable_confirmatory_findings.tsv"))
stable_interaction <- stable[effect == "accession_time_interaction", unique(gene)]
stopifnot(length(stable_interaction) == 5L)
write_tsv(peg_contrasts[gene %in% stable_interaction],
          "PEG_five_stable_interaction_gene_contrasts.tsv")
write_tsv(peg_summary[gene %in% stable_interaction],
          "PEG_five_stable_interaction_gene_expression.tsv")

## Candidate-level two-dataset effect meta-analysis -------------------------
message("Computing candidate-level cross-dataset effect meta-analysis")
g226_path <- file.path(root, "results", "gse226105_raw_reanalysis", "deseq2",
                       "GSE226105_genomewide_DESeq2_results.tsv")
g243_path <- file.path(root, "external_gse243365", "results",
                       "GSE243365_genomewide_DESeq2.tsv")
g226 <- fread(g226_path)
g243 <- fread(g243_path)
g226[, AGI := toupper(AGI)]
g243[, AGI := toupper(AGI)]
mapping <- fread(file.path(root, "results", "formal_integrated_evidence",
                           "arabidopsis_56_formal_integrated_evidence.tsv"))
mapping[, AGI := toupper(AGI)]
stopifnot(nrow(mapping) == 56L, !anyDuplicated(mapping$AGI))

meta_input <- merge(
  mapping[, .(AGI, carex_genes, families, arabidopsis_symbols, meta_significant,
              meta_probe_directions)],
  g226[, .(AGI, log2FC_GSE226105 = log2FoldChange,
           SE_GSE226105 = lfcSE, FDR_GSE226105 = padj)],
  by = "AGI", all.x = TRUE
)
meta_input <- merge(
  meta_input,
  g243[, .(AGI, log2FC_GSE243365 = log2FoldChange,
           SE_GSE243365 = lfcSE, FDR_GSE243365 = padj)],
  by = "AGI", all.x = TRUE
)

meta_rows <- lapply(seq_len(nrow(meta_input)), function(i) {
  x <- meta_input[i]
  yi <- c(x$log2FC_GSE226105, x$log2FC_GSE243365)
  sei <- c(x$SE_GSE226105, x$SE_GSE243365)
  ok <- is.finite(yi) & is.finite(sei) & sei > 0
  yi <- yi[ok]
  sei <- sei[ok]
  k <- length(yi)
  if (k < 2L) return(data.table(AGI = x$AGI, k = k))
  wi <- 1 / sei^2
  fixed <- sum(wi * yi) / sum(wi)
  fixed_se <- sqrt(1 / sum(wi))
  fixed_z <- fixed / fixed_se
  fixed_p <- 2 * pnorm(abs(fixed_z), lower.tail = FALSE)
  Q <- sum(wi * (yi - fixed)^2)
  Q_p <- pchisq(Q, df = k - 1L, lower.tail = FALSE)
  C <- sum(wi) - sum(wi^2) / sum(wi)
  tau2 <- max(0, (Q - (k - 1L)) / C)
  wr <- 1 / (sei^2 + tau2)
  random <- sum(wr * yi) / sum(wr)
  random_se <- sqrt(1 / sum(wr))
  random_p <- 2 * pnorm(abs(random / random_se), lower.tail = FALSE)
  data.table(
    AGI = x$AGI, k = k,
    fixed_log2FC = fixed, fixed_SE = fixed_se,
    fixed_CI95_low = fixed - qnorm(0.975) * fixed_se,
    fixed_CI95_high = fixed + qnorm(0.975) * fixed_se,
    fixed_z = fixed_z, fixed_pvalue = fixed_p,
    Q = Q, Q_df = k - 1L, Q_pvalue = Q_p,
    I2_percent = if (Q > 0) max(0, (Q - (k - 1L)) / Q) * 100 else 0,
    tau2_DL = tau2,
    random_log2FC = random, random_SE = random_se,
    random_CI95_low = random - qnorm(0.975) * random_se,
    random_CI95_high = random + qnorm(0.975) * random_se,
    random_pvalue = random_p
  )
})
candidate_meta <- rbindlist(meta_rows, fill = TRUE)
candidate_meta[, fixed_FDR_56 := p.adjust(fixed_pvalue, method = "BH")]
candidate_meta[, random_FDR_56 := p.adjust(random_pvalue, method = "BH")]
candidate_meta <- merge(meta_input, candidate_meta, by = "AGI", all.x = TRUE)
candidate_meta[, meta_estimable_two_datasets := k == 2L]
candidate_meta[, fixed_FDR005 := meta_estimable_two_datasets & fixed_FDR_56 < 0.05]
candidate_meta[, random_FDR005 := meta_estimable_two_datasets & random_FDR_56 < 0.05]
candidate_meta[, high_heterogeneity_I2_gt50 :=
                 meta_estimable_two_datasets & I2_percent > 50]
candidate_meta[, fixed_direction := fifelse(fixed_log2FC > 0, "up",
                                            fifelse(fixed_log2FC < 0, "down", "zero"))]
candidate_meta[, same_direction_raw :=
                 meta_estimable_two_datasets &
                 sign(log2FC_GSE226105) == sign(log2FC_GSE243365)]
candidate_meta[, abs_fixed_log2FC := abs(fixed_log2FC)]
setorder(candidate_meta, fixed_FDR_56, -abs_fixed_log2FC)
write_tsv(candidate_meta, "Arabidopsis_56_two_dataset_effect_meta_analysis.tsv")

## GO-BP concordance and overlap significance -------------------------------
message("Quantifying GO-BP concordance and overlap significance")
consensus <- fread(file.path(root, "enrichment", "results",
                             "GSE226105_GSE243365_GO_BP_GSEA_consensus.tsv"))
consensus <- consensus[is.finite(NES_GSE226105) & is.finite(NES_GSE243365)]
n_common <- nrow(consensus)
rho <- suppressWarnings(cor(consensus$NES_GSE226105, consensus$NES_GSE243365,
                            method = "spearman"))
rho_test <- suppressWarnings(cor.test(consensus$NES_GSE226105,
                                      consensus$NES_GSE243365,
                                      method = "spearman", exact = FALSE))
B <- 10000L
set.seed(20260801)
boot_rho <- replicate(B, {
  idx <- sample.int(n_common, n_common, replace = TRUE)
  suppressWarnings(cor(consensus$NES_GSE226105[idx],
                       consensus$NES_GSE243365[idx], method = "spearman"))
})
rho_ci <- quantile(boot_rho, c(0.025, 0.975), na.rm = TRUE)

sig1 <- consensus$padj_GSE226105 < 0.05
sig2 <- consensus$padj_GSE243365 < 0.05
same_sign <- sign(consensus$NES_GSE226105) == sign(consensus$NES_GSE243365)
overlap_any <- sum(sig1 & sig2)
overlap_directional <- sum(sig1 & sig2 & same_sign)
hyper_p <- phyper(overlap_any - 1L, sum(sig1), n_common - sum(sig1), sum(sig2),
                  lower.tail = FALSE)

set.seed(20260801)
perm_rho <- numeric(B)
perm_overlap <- integer(B)
for (b in seq_len(B)) {
  idx <- sample.int(n_common)
  perm_rho[b] <- suppressWarnings(cor(consensus$NES_GSE226105,
                                      consensus$NES_GSE243365[idx],
                                      method = "spearman"))
  perm_overlap[b] <- sum(sig1 & sig2[idx] &
                         sign(consensus$NES_GSE226105) ==
                           sign(consensus$NES_GSE243365[idx]))
}
rho_perm_p <- (sum(abs(perm_rho) >= abs(rho)) + 1) / (B + 1)
overlap_perm_p <- (sum(perm_overlap >= overlap_directional) + 1) / (B + 1)

go_stats <- data.table(
  common_tested_terms = n_common,
  Spearman_rho = rho,
  term_label_Spearman_asymptotic_p_descriptive = rho_test$p.value,
  term_label_bootstrap_CI95_low_descriptive = unname(rho_ci[[1L]]),
  term_label_bootstrap_CI95_high_descriptive = unname(rho_ci[[2L]]),
  term_label_permutation_p_descriptive = rho_perm_p,
  GSE226105_FDR005_among_common = sum(sig1),
  GSE243365_FDR005_among_common = sum(sig2),
  FDR005_overlap_any_direction = overlap_any,
  FDR005_same_direction_overlap = overlap_directional,
  all_term_sign_concordance_n = sum(same_sign),
  all_term_sign_concordance_fraction = mean(same_sign),
  term_label_hypergeometric_overlap_p_descriptive = hyper_p,
  term_label_directional_overlap_permutation_p_descriptive = overlap_perm_p,
  permutations = B,
  bootstrap_replicates = B,
  inference_note = paste(
    "GO terms are overlapping and hierarchical; term-label tests are descriptive.",
    "Sample-label exact permutation results preserving GO dependence are reported separately."
  )
)
write_tsv(go_stats, "GO_BP_cross_dataset_concordance_statistics.tsv")

## Sample QC and leave-one-sample-out DE/GSEA -------------------------------
message("Running sample-level robustness analyses")
read_gse243_counts <- function() {
  manifest <- fread(file.path(root, "external_gse243365", "metadata",
                              "download_manifest.tsv"))
  one <- lapply(file.path(root, "external_gse243365", "raw_counts", manifest$file),
                function(path) {
                  x <- fread(cmd = paste("gzip -dc", shQuote(path)), skip = 1L,
                             showProgress = FALSE)
                  data.table(Geneid = x[[1L]], count = as.integer(x[[ncol(x)]]))
                })
  ids <- one[[1L]]$Geneid
  stopifnot(all(vapply(one, function(x) identical(x$Geneid, ids), logical(1))))
  mat <- do.call(cbind, lapply(one, `[[`, "count"))
  rownames(mat) <- ids
  colnames(mat) <- manifest$gsm
  storage.mode(mat) <- "integer"
  list(counts = mat, condition = manifest$condition, sample = manifest$gsm)
}

read_gse226_counts <- function() {
  x <- fread(file.path(root, "results", "gse226105_raw_reanalysis",
                       "GSE226105_raw_gene_counts.tsv"))
  meta <- fread(file.path(root, "metadata", "GSE226105_PRESPECIFIED_SAMPLES.tsv"))
  gsm_cols <- meta$gsm
  mat <- as.matrix(x[, ..gsm_cols])
  rownames(mat) <- x$Geneid
  colnames(mat) <- meta$gsm
  storage.mode(mat) <- "integer"
  list(counts = mat, condition = meta$condition, sample = meta$gsm)
}

run_balanced_label_gsea <- function(dataset, obj) {
  counts_all <- obj$counts
  keep_gene <- rowSums(counts_all >= 10L) >= 3L
  counts_model <- counts_all[keep_gene, , drop = FALSE]
  n_drought <- sum(obj$condition == "drought")
  allocations <- combn(seq_len(ncol(counts_model)), n_drought, simplify = FALSE)
  observed_key <- paste(which(obj$condition == "drought"), collapse = ",")
  rbindlist(lapply(seq_along(allocations), function(i) {
    drought_idx <- allocations[[i]]
    condition <- factor(
      ifelse(seq_len(ncol(counts_model)) %in% drought_idx, "drought", "control"),
      levels = c("control", "drought")
    )
    coldata <- data.frame(condition = condition, row.names = colnames(counts_model))
    dds <- DESeqDataSetFromMatrix(counts_model, coldata, ~ condition)
    dds <- DESeq(dds, quiet = TRUE)
    rr <- as.data.table(as.data.frame(results(
      dds, contrast = c("condition", "drought", "control"), alpha = 0.05
    )), keep.rownames = "AGI")
    ranks_dt <- rr[is.finite(stat), .(AGI, stat)]
    ranks_dt <- ranks_dt[!duplicated(AGI)]
    ranks <- ranks_dt$stat
    names(ranks) <- ranks_dt$AGI
    ranks <- sort(ranks, decreasing = TRUE)
    fg <- as.data.table(fgseaMultilevel(
      pathways = pathways, stats = ranks,
      minSize = 15L, maxSize = 500L, eps = 1e-10,
      scoreType = "std", nproc = 1
    ))
    fg[, `:=`(
      dataset = dataset,
      allocation_id = i,
      drought_sample_indices = paste(drought_idx, collapse = ","),
      is_observed_allocation = paste(drought_idx, collapse = ",") == observed_key,
      GO_ID = pathway
    )]
    fg[, .(dataset, allocation_id, drought_sample_indices,
           is_observed_allocation, GO_ID, size, NES, pval, padj)]
  }), use.names = TRUE, fill = TRUE)
}

pair_balanced_label_gsea <- function(x226, x243) {
  ids226 <- sort(unique(x226$allocation_id))
  ids243 <- sort(unique(x243$allocation_id))
  rbindlist(lapply(ids226, function(i) {
    a <- x226[allocation_id == i,
              .(GO_ID, NES_226 = NES, padj_226 = padj,
                observed_226 = is_observed_allocation)]
    rbindlist(lapply(ids243, function(j) {
      b <- x243[allocation_id == j,
                .(GO_ID, NES_243 = NES, padj_243 = padj,
                  observed_243 = is_observed_allocation)]
      z <- merge(a, b, by = "GO_ID")
      data.table(
        allocation_id_GSE226105 = i,
        allocation_id_GSE243365 = j,
        observed_pair = all(z$observed_226) & all(z$observed_243),
        common_terms = nrow(z),
        Spearman_rho = suppressWarnings(cor(z$NES_226, z$NES_243,
                                             method = "spearman")),
        FDR005_same_direction_overlap = sum(
          z$padj_226 < 0.05 & z$padj_243 < 0.05 &
            sign(z$NES_226) == sign(z$NES_243), na.rm = TRUE
        )
      )
    }))
  }))
}

candidate_ids <- mapping$AGI
consensus_ids <- consensus[padj_GSE226105 < 0.05 & padj_GSE243365 < 0.05 & same_sign,
                           GO_ID]
consensus_direction <- setNames(sign(consensus$NES_GSE226105), consensus$GO_ID)

robust_one_dataset <- function(dataset, obj, full_de) {
  counts_all <- obj$counts
  condition <- factor(obj$condition, levels = c("control", "drought"))
  keep_gene <- rowSums(counts_all >= 10L) >= 3L
  counts_model <- counts_all[keep_gene, , drop = FALSE]
  coldata <- data.frame(condition = condition, row.names = colnames(counts_model))
  dds <- DESeqDataSetFromMatrix(counts_model, coldata, ~ condition)
  dds <- DESeq(dds, quiet = TRUE)
  norm <- counts(dds, normalized = TRUE)
  cor_mat <- cor(log2(norm + 1), method = "spearman")
  cor_long <- as.data.table(as.table(cor_mat))
  setnames(cor_long, c("sample_1", "sample_2", "spearman_r"))
  cor_long[, dataset := dataset]

  cooks <- assays(dds)[["cooks"]]
  p_model <- ncol(model.matrix(~ condition, colData(dds)))
  cook_cutoff <- qf(0.99, p_model, ncol(dds) - p_model)
  cook_summary <- rbindlist(lapply(seq_len(ncol(dds)), function(j) {
    v <- cooks[, j]
    data.table(dataset = dataset, sample = colnames(dds)[j],
               condition = as.character(condition[j]),
               max_Cooks_distance = max(v, na.rm = TRUE),
               median_Cooks_distance = median(v, na.rm = TRUE),
               genes_above_DESeq2_cutoff = sum(v > cook_cutoff, na.rm = TRUE),
               DESeq2_Cooks_cutoff = cook_cutoff)
  }))

  full_map <- full_de[match(candidate_ids, AGI)]
  candidate_loo <- list()
  gsea_loo <- list()
  for (omit in seq_len(ncol(counts_model))) {
    keep_sample <- seq_len(ncol(counts_model)) != omit
    dds_loo <- DESeqDataSetFromMatrix(
      counts_model[, keep_sample, drop = FALSE],
      coldata[keep_sample, , drop = FALSE], ~ condition
    )
    dds_loo <- DESeq(dds_loo, quiet = TRUE)
    rr <- as.data.table(as.data.frame(results(
      dds_loo, contrast = c("condition", "drought", "control"), alpha = 0.05
    )), keep.rownames = "AGI")
    candidate_loo[[omit]] <- data.table(
      dataset = dataset, omitted_sample = colnames(counts_model)[omit],
      AGI = candidate_ids,
      full_log2FC = full_map$log2FoldChange,
      loo_log2FC = rr$log2FoldChange[match(candidate_ids, rr$AGI)],
      loo_padj = rr$padj[match(candidate_ids, rr$AGI)]
    )
    candidate_loo[[omit]][, estimable :=
                           is.finite(full_log2FC) & is.finite(loo_log2FC)]
    candidate_loo[[omit]][, direction_matches_full :=
                           estimable & sign(loo_log2FC) == sign(full_log2FC)]
    candidate_loo[[omit]][, FDR005_retained :=
                           estimable & is.finite(loo_padj) & loo_padj < 0.05]

    ranks_dt <- rr[is.finite(stat), .(AGI, stat)]
    ranks_dt <- ranks_dt[!duplicated(AGI)]
    ranks <- ranks_dt$stat
    names(ranks) <- ranks_dt$AGI
    ranks <- sort(ranks, decreasing = TRUE)
    fg_all <- as.data.table(fgseaMultilevel(
      pathways = pathways, stats = ranks,
      minSize = 15L, maxSize = 500L, eps = 1e-10,
      scoreType = "std", nproc = 1
    ))
    fg_all[, GO_ID := pathway]
    target <- data.table(GO_ID = consensus_ids)
    fg <- merge(
      target,
      fg_all[, .(GO_ID, size, NES, pval, padj)],
      by = "GO_ID", all.x = TRUE
    )
    fg[, `:=`(
      dataset = dataset,
      omitted_sample = colnames(counts_model)[omit],
      GO_term = unname(go_names[GO_ID]),
      full_consensus_direction = unname(consensus_direction[GO_ID]),
      full_universe_adjustment_family_n = nrow(fg_all),
      eligible_in_loo = is.finite(NES) & is.finite(padj),
      FDR005_retained = is.finite(padj) & padj < 0.05
    )]
    fg[, direction_matches_full :=
         eligible_in_loo & sign(NES) == full_consensus_direction]
    gsea_loo[[omit]] <- fg[, .(
      dataset, omitted_sample, GO_ID, GO_term, size, NES, pval, padj,
      full_consensus_direction, full_universe_adjustment_family_n,
      eligible_in_loo, direction_matches_full, FDR005_retained
    )]
  }
  list(correlation = cor_long, cooks = cook_summary,
       candidate_loo = rbindlist(candidate_loo),
       gsea_loo = rbindlist(gsea_loo))
}

obj226 <- read_gse226_counts()
obj243 <- read_gse243_counts()

message("Running exact balanced sample-label permutations for GO dependence-aware inference")
label_gsea_226 <- run_balanced_label_gsea("GSE226105", obj226)
label_gsea_243 <- run_balanced_label_gsea("GSE243365", obj243)
label_pair_stats <- pair_balanced_label_gsea(label_gsea_226, label_gsea_243)
observed_pair <- label_pair_stats[observed_pair == TRUE]
stopifnot(nrow(observed_pair) == 1L, nrow(label_pair_stats) == 400L)
sample_label_stats <- data.table(
  allocation_pairs = nrow(label_pair_stats),
  observed_Spearman_rho = observed_pair$Spearman_rho,
  exact_two_sided_Spearman_p = mean(
    abs(label_pair_stats$Spearman_rho) >= abs(observed_pair$Spearman_rho)
  ),
  observed_FDR005_same_direction_overlap =
    observed_pair$FDR005_same_direction_overlap,
  exact_upper_tail_overlap_p = mean(
    label_pair_stats$FDR005_same_direction_overlap >=
      observed_pair$FDR005_same_direction_overlap
  ),
  permutation_unit = "balanced sample-label allocation within each 3-vs-3 dataset",
  dependence_note = paste(
    "Each allocation reruns DESeq2 and full-universe GSEA;",
    "GO overlap and hierarchy are preserved within each allocation."
  )
)
write_tsv(label_gsea_226, "GSE226105_balanced_label_permutation_GSEA.tsv")
write_tsv(label_gsea_243, "GSE243365_balanced_label_permutation_GSEA.tsv")
write_tsv(label_pair_stats, "GO_BP_balanced_sample_label_pair_statistics.tsv")
write_tsv(sample_label_stats, "GO_BP_balanced_sample_label_permutation_summary.tsv")
go_stats[, `:=`(
  sample_label_allocation_pairs = sample_label_stats$allocation_pairs,
  sample_label_exact_two_sided_Spearman_p =
    sample_label_stats$exact_two_sided_Spearman_p,
  sample_label_exact_upper_tail_directional_overlap_p =
    sample_label_stats$exact_upper_tail_overlap_p
)]
write_tsv(go_stats, "GO_BP_cross_dataset_concordance_statistics.tsv")

rob226 <- robust_one_dataset("GSE226105", obj226, g226)
rob243 <- robust_one_dataset("GSE243365", obj243, g243)

sample_cor <- rbindlist(list(rob226$correlation, rob243$correlation))
cooks_summary <- rbindlist(list(rob226$cooks, rob243$cooks))
candidate_loo <- rbindlist(list(rob226$candidate_loo, rob243$candidate_loo))
gsea_loo <- rbindlist(list(rob226$gsea_loo, rob243$gsea_loo))

candidate_loo_summary <- candidate_loo[, .(
  leave_one_out_runs = .N,
  estimable_runs = sum(estimable),
  direction_matches_full_n = sum(direction_matches_full),
  direction_stability_fraction = if (sum(estimable) > 0)
    sum(direction_matches_full) / sum(estimable) else NA_real_,
  FDR005_retained_n = sum(FDR005_retained),
  FDR005_retained_fraction = if (sum(estimable) > 0)
    sum(FDR005_retained) / sum(estimable) else NA_real_,
  min_loo_log2FC = if (any(estimable)) min(loo_log2FC[estimable]) else NA_real_,
  max_loo_log2FC = if (any(estimable)) max(loo_log2FC[estimable]) else NA_real_
), by = .(dataset, AGI, full_log2FC)]

gsea_loo_summary <- gsea_loo[, .(
  leave_one_out_runs = .N,
  eligible_runs = sum(eligible_in_loo),
  min_adjustment_family_n = min(full_universe_adjustment_family_n),
  max_adjustment_family_n = max(full_universe_adjustment_family_n),
  direction_matches_full_n = sum(direction_matches_full),
  direction_stability_fraction = sum(direction_matches_full) / .N,
  FDR005_retained_n = sum(FDR005_retained),
  FDR005_retained_fraction = sum(FDR005_retained) / .N,
  min_NES = if (any(eligible_in_loo)) min(NES[eligible_in_loo]) else NA_real_,
  max_NES = if (any(eligible_in_loo)) max(NES[eligible_in_loo]) else NA_real_
), by = .(dataset, GO_ID, GO_term, full_consensus_direction)]

write_tsv(sample_cor, "Public_RNAseq_sample_correlations.tsv")
write_tsv(cooks_summary, "Public_RNAseq_sample_Cooks_diagnostics.tsv")
write_tsv(candidate_loo, "Arabidopsis_56_leave_one_sample_out_results.tsv")
write_tsv(candidate_loo_summary, "Arabidopsis_56_leave_one_sample_out_summary.tsv")
write_tsv(gsea_loo, "Consensus_GO_leave_one_sample_out_GSEA.tsv")
write_tsv(gsea_loo_summary, "Consensus_GO_leave_one_sample_out_GSEA_summary.tsv")

facts <- data.table(
  metric = c(
    "PEG_genes", "PEG_samples", "PEG_stable_interaction_genes",
    "PEG_contrasts_per_gene", "candidate_mapped_homolog_groups",
    "candidate_two_dataset_estimable_groups", "candidate_single_dataset_groups",
    "candidate_fixed_effect_FDR005", "candidate_random_effect_FDR005",
    "candidate_fixed_FDR005_with_I2_gt50", "candidate_same_direction_raw",
    "GO_common_tested_terms", "GO_same_direction_FDR005_terms",
    "GO_NES_Spearman_rho", "GO_sample_label_exact_Spearman_p",
    "GO_sample_label_exact_directional_overlap_p",
    "candidate_leave_one_out_rows_total", "candidate_leave_one_out_rows_estimable",
    "GO_leave_one_out_rows", "GO_LOO_min_full_adjustment_family_n",
    "samples_with_Cooks_above_DESeq2_cutoff"
  ),
  value = c(
    nrow(peg), length(sample_names), length(stable_interaction),
    length(contrast_def), nrow(candidate_meta),
    sum(candidate_meta$meta_estimable_two_datasets),
    sum(candidate_meta$k == 1L),
    sum(candidate_meta$fixed_FDR005, na.rm = TRUE),
    sum(candidate_meta$random_FDR005, na.rm = TRUE),
    sum(candidate_meta$fixed_FDR005 &
          candidate_meta$high_heterogeneity_I2_gt50, na.rm = TRUE),
    sum(candidate_meta$same_direction_raw, na.rm = TRUE),
    n_common, overlap_directional, rho,
    sample_label_stats$exact_two_sided_Spearman_p,
    sample_label_stats$exact_upper_tail_overlap_p,
    nrow(candidate_loo), sum(candidate_loo$estimable), nrow(gsea_loo),
    min(gsea_loo$full_universe_adjustment_family_n),
    sum(cooks_summary$genes_above_DESeq2_cutoff > 0)
  )
)
write_tsv(facts, "MAJOR_REVISION_ANALYSIS_FACTS.tsv")

writeLines(c(
  "PASS statistical_workload_executed_on_remote_server",
  "PASS PEG_simple_contrasts_include_effect_SE_CI_and_FDR",
  "PASS candidate_meta_analysis_uses_two_DESeq2_log2FC_and_SE_estimates",
  "PASS candidate_meta_reports_48_two_dataset_estimable_and_8_single_dataset_groups",
  "PASS fixed_random_effects_and_I2_are_reported_together",
  "PASS GO_concordance_includes_dependence_preserving_balanced_sample_label_exact_permutation",
  "PASS GO_LOO_reruns_full_eligible_universe_before_BH_and_extracts_94_consensus_terms",
  "PASS public_RNAseq_robustness_includes_sample_correlation_Cooks_candidate_LOO_and_full_universe_GO_LOO",
  "PASS no_schematic_or_mechanistic_diagram_created"
), file.path(res_dir, "MAJOR_REVISION_ACCEPTANCE.txt"))
writeLines(capture.output(sessionInfo()), file.path(res_dir, "MAJOR_REVISION_sessionInfo.txt"))
system2("sha256sum", list.files(res_dir, full.names = TRUE),
        stdout = file.path(out_root, "MAJOR_REVISION_RESULTS_SHA256SUMS.txt"))

cat("MAJOR_REVISION_FACTS\n")
print(facts)
cat("GO_CONCORDANCE\n")
print(go_stats)
