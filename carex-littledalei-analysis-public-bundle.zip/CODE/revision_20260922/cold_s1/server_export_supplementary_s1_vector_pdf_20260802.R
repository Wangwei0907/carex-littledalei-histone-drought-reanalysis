#!/usr/bin/env Rscript

options(stringsAsFactors = FALSE)
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) {
  stop("Usage: server_export_supplementary_s1_vector_pdf_20260802.R INPUT_DIR OUTPUT_DIR")
}

input_dir <- normalizePath(args[[1]], mustWork = TRUE)
output_dir <- args[[2]]
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
  library(cowplot)
})

module_order <- c(
  "early_up", "early_down", "intermediate_up", "intermediate_down",
  "late_up", "late_down"
)
time_order <- c(0, 0.5, 4, 12, 24, 48)
palette <- c(
  early_up = "#5B8CC0", early_down = "#D9A066",
  intermediate_up = "#2D6EA3", intermediate_down = "#D97800",
  late_up = "#174C75", late_down = "#A64B00"
)

theme_data <- theme_bw(base_size = 9) +
  theme(
    plot.title = element_text(face = "bold", size = 10, hjust = 0),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "#E4E9ED", linewidth = 0.3),
    axis.text = element_text(color = "#1E252B"),
    axis.title = element_text(color = "#1E252B"),
    legend.title = element_blank(),
    plot.margin = margin(5, 7, 5, 5)
  )

counts <- fread(file.path(input_dir, "GSE129860_genomewide_DEG_counts_by_time.tsv"))
assignments <- fread(file.path(input_dir, "GSE129860_genomewide_temporal_module_assignments.tsv"))
trajectories <- fread(file.path(input_dir, "GSE129860_DEG_normalized_time_trajectory_zscores.tsv"))
strict <- fread(file.path(input_dir, "strict_histone_modifier_temporal_module_membership.tsv"))
if (!"trinity_gene" %in% names(trajectories)) setnames(trajectories, 1L, "trinity_gene")
trajectory_time_columns <- names(trajectories)[2:7]
strict_time_columns <- tail(names(strict), 6)

counts_long <- rbindlist(list(
  counts[, .(contrast, direction = "Up", value = up)],
  counts[, .(contrast, direction = "Down", value = -down)]
))
counts_long[, contrast := factor(contrast, levels = counts$contrast)]
p_a <- ggplot(counts_long, aes(contrast, value, fill = direction)) +
  geom_hline(yintercept = 0, color = "#555555", linewidth = 0.4) +
  geom_col(width = 0.72) +
  scale_fill_manual(values = c(Up = "#2D6EA3", Down = "#D97800")) +
  scale_y_continuous(labels = abs) +
  labs(title = "Cold-responsive genes by time", x = NULL,
       y = "Genome-wide significant genes") +
  theme_data +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "bottom")

module_counts <- assignments[, .N, by = response_module]
module_counts[, response_module := factor(response_module, levels = rev(module_order))]
p_b <- ggplot(module_counts, aes(response_module, N, fill = response_module)) +
  geom_col(width = 0.72) +
  geom_text(aes(label = N), hjust = -0.15, size = 3) +
  coord_flip(clip = "off") +
  scale_fill_manual(values = palette, guide = "none") +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12))) +
  labs(title = "Deterministic temporal-response modules", x = NULL,
       y = "Genes assigned by dominant contrast") +
  theme_data

trajectory <- merge(
  assignments[, .(trinity_gene, response_module)], trajectories,
  by = "trinity_gene", all.x = TRUE
)
trajectory_long <- melt(
  trajectory, id.vars = c("trinity_gene", "response_module"),
  measure.vars = trajectory_time_columns, variable.name = "time_column", value.name = "z_score"
)
trajectory_long[, time_h := time_order[match(as.character(time_column), trajectory_time_columns)]]
trajectory_long[, time_index := match(time_h, time_order)]
trajectory_summary <- trajectory_long[, .(
  mean_z = mean(z_score, na.rm = TRUE),
  q25 = quantile(z_score, 0.25, na.rm = TRUE),
  q75 = quantile(z_score, 0.75, na.rm = TRUE),
  genes = uniqueN(trinity_gene)
), by = .(response_module, time_h, time_index)]
trajectory_summary[, response_module := factor(response_module, levels = module_order)]
p_c <- ggplot(trajectory_summary, aes(time_index, mean_z, color = response_module,
                                       fill = response_module, group = response_module)) +
  geom_hline(yintercept = 0, color = "#777777", linewidth = 0.4, linetype = 2) +
  geom_ribbon(aes(ymin = q25, ymax = q75), alpha = 0.12, color = NA) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 1.8) +
  scale_color_manual(values = palette) +
  scale_fill_manual(values = palette) +
  scale_x_continuous(breaks = seq_along(time_order), labels = time_order) +
  labs(title = "Genome-wide module trajectories (band: gene IQR)",
       x = "Cold exposure at -5 °C (h)",
       y = "Mean row z-score of log2 normalized count") +
  theme_data + theme(legend.position = "bottom", legend.text = element_text(size = 7))

strict_long <- melt(
  strict, id.vars = c("strict_histone_modifier_gene", "response_module"),
  measure.vars = strict_time_columns, variable.name = "time_column", value.name = "z_score"
)
strict_long[, time_h := time_order[match(as.character(time_column), strict_time_columns)]]
strict_long[, time_index := match(time_h, time_order)]
strict_long[, response_module := factor(response_module, levels = module_order)]
strict_long[, gene_label := paste0(strict_histone_modifier_gene, " · ", response_module)]
gene_legend <- unique(strict_long[, .(gene_label, response_module)])
gene_colors <- setNames(palette[as.character(gene_legend$response_module)], gene_legend$gene_label)
gene_shapes <- setNames(c(16, 17, 15, 3, 7)[seq_len(nrow(gene_legend))], gene_legend$gene_label)
p_d <- ggplot(strict_long, aes(time_index, z_score, color = gene_label,
                               group = gene_label, shape = gene_label)) +
  geom_hline(yintercept = 0, color = "#777777", linewidth = 0.4, linetype = 2) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 2) +
  scale_color_manual(values = gene_colors) +
  scale_shape_manual(values = gene_shapes) +
  scale_x_continuous(breaks = seq_along(time_order), labels = time_order) +
  labs(title = "Significant strict histone modifiers within modules",
       x = "Cold exposure at -5 °C (h)",
       y = "Row z-score of log2 normalized count") +
  guides(color = guide_legend(nrow = 2, byrow = TRUE),
         shape = guide_legend(nrow = 2, byrow = TRUE)) +
  theme_data + theme(legend.position = "bottom", legend.text = element_text(size = 7))

figure <- plot_grid(
  p_a, p_b, p_c, p_d,
  labels = LETTERS[1:4], label_fontface = "bold", label_size = 12,
  ncol = 2, align = "hv", rel_heights = c(0.85, 1.15)
)
title <- ggdraw() + draw_label(
  "Same-species public count RNA-seq: cold-response timing and histone-modifier context",
  fontface = "bold", size = 15, x = 0.5, hjust = 0.5
)
final <- plot_grid(title, figure, ncol = 1, rel_heights = c(0.06, 0.94))

output_pdf <- file.path(output_dir, "Supplementary_Figure_S1_same_species_cold_modules_vector.pdf")
ggsave(
  output_pdf, final, device = cairo_pdf,
  width = 14, height = 10.5, units = "in", bg = "white"
)

writeLines(c(
  "PASS supplementary Figure S1 regenerated from machine-readable tables",
  "PASS PDF uses vector geoms only; no raster plotting layer is used",
  sprintf("PASS temporal modules=%d", uniqueN(assignments$response_module)),
  sprintf("PASS strict histone modifiers=%d", uniqueN(strict$strict_histone_modifier_gene))
), file.path(output_dir, "VECTOR_S1_ACCEPTANCE.txt"))

cat(sprintf("vector_pdf=%s\n", output_pdf))
